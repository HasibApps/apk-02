package com.example;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FolderManager {

    private static final String PREF_NAME = "pdf_folder_prefs";
    private static final String KEY_FOLDERS = "custom_folders";
    private static final String KEY_HIDDEN_FOLDERS = "hidden_default_folders";
    private static final String KEY_MAPPING_PREFIX = "file_folder_";

    public static final String FOLDER_ALL = "All";
    public static final String FOLDER_FAVORITES = "Favorites";
    public static final String FOLDER_SCREENSHOTS = "Screenshots";
    public static final String FOLDER_DOWNLOAD = "Download";

    private final Context context;
    private final SharedPreferences prefs;

    public FolderManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public List<String> getAllFolders() {
        List<String> list = new ArrayList<>();
        Set<String> hidden = prefs.getStringSet(KEY_HIDDEN_FOLDERS, new HashSet<>());
        if (hidden == null || !hidden.contains(FOLDER_SCREENSHOTS)) {
            list.add(FOLDER_SCREENSHOTS);
        }
        if (hidden == null || !hidden.contains(FOLDER_DOWNLOAD)) {
            list.add(FOLDER_DOWNLOAD);
        }

        Set<String> custom = prefs.getStringSet(KEY_FOLDERS, new HashSet<>());
        if (custom != null) {
            for (String f : custom) {
                if (!list.contains(f)) {
                    list.add(f);
                }
            }
        }
        return list;
    }

    public void createFolder(String folderName) {
        if (folderName == null || folderName.trim().isEmpty()) return;
        String name = folderName.trim();
        // Unhide if it was hidden
        Set<String> hidden = prefs.getStringSet(KEY_HIDDEN_FOLDERS, new HashSet<>());
        if (hidden != null && hidden.contains(name)) {
            Set<String> updatedHidden = new HashSet<>(hidden);
            updatedHidden.remove(name);
            prefs.edit().putStringSet(KEY_HIDDEN_FOLDERS, updatedHidden).apply();
        }

        Set<String> existing = prefs.getStringSet(KEY_FOLDERS, new HashSet<>());
        Set<String> updated = new HashSet<>(existing);
        updated.add(name);
        prefs.edit().putStringSet(KEY_FOLDERS, updated).apply();
    }

    public void deleteFolder(String folderName) {
        if (folderName == null || folderName.trim().isEmpty()) return;
        String name = folderName.trim();

        // If custom folder
        Set<String> existing = prefs.getStringSet(KEY_FOLDERS, new HashSet<>());
        if (existing != null && existing.contains(name)) {
            Set<String> updated = new HashSet<>(existing);
            updated.remove(name);
            prefs.edit().putStringSet(KEY_FOLDERS, updated).apply();
        }

        // If default folder, record in hidden
        if (FOLDER_SCREENSHOTS.equalsIgnoreCase(name) || FOLDER_DOWNLOAD.equalsIgnoreCase(name)) {
            Set<String> hidden = prefs.getStringSet(KEY_HIDDEN_FOLDERS, new HashSet<>());
            Set<String> updatedHidden = new HashSet<>(hidden);
            updatedHidden.add(name);
            prefs.edit().putStringSet(KEY_HIDDEN_FOLDERS, updatedHidden).apply();
        }
    }

    public void renameFolder(String oldName, String newName) {
        if (oldName == null || newName == null || newName.trim().isEmpty()) return;
        String cleanNew = newName.trim();
        createFolder(cleanNew);

        Map<String, ?> all = prefs.getAll();
        SharedPreferences.Editor edit = prefs.edit();
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            if (entry.getKey().startsWith(KEY_MAPPING_PREFIX) && oldName.equals(entry.getValue())) {
                edit.putString(entry.getKey(), cleanNew);
            }
        }
        edit.apply();

        deleteFolder(oldName);
    }

    public void assignPdfToFolder(String pdfIdentifier, String folderName) {
        if (pdfIdentifier == null) return;
        prefs.edit().putString(KEY_MAPPING_PREFIX + pdfIdentifier, folderName).apply();
    }

    public String getFolderForPdf(PdfFile pdf) {
        if (pdf == null) return null;
        String id = pdf.getPath() != null ? pdf.getPath() : pdf.getName();
        String assigned = prefs.getString(KEY_MAPPING_PREFIX + id, null);
        if (assigned != null) return assigned;

        // Check if default folder is hidden
        Set<String> hidden = prefs.getStringSet(KEY_HIDDEN_FOLDERS, new HashSet<>());

        // Auto heuristic for default folders
        String lowerName = pdf.getName().toLowerCase();
        String lowerPath = pdf.getPath() != null ? pdf.getPath().toLowerCase() : "";
        if ((lowerName.contains("screenshot") || lowerPath.contains("screenshot")) &&
                (hidden == null || !hidden.contains(FOLDER_SCREENSHOTS))) {
            return FOLDER_SCREENSHOTS;
        }
        if ((lowerPath.contains("download") || lowerName.contains("download")) &&
                (hidden == null || !hidden.contains(FOLDER_DOWNLOAD))) {
            return FOLDER_DOWNLOAD;
        }
        return null;
    }

    public List<PdfFile> filterByFolder(List<PdfFile> allFiles, String folder) {
        if (folder == null || FOLDER_ALL.equalsIgnoreCase(folder)) {
            return new ArrayList<>(allFiles);
        }
        if (FOLDER_FAVORITES.equalsIgnoreCase(folder)) {
            FavoritesManager favMgr = new FavoritesManager(context);
            List<PdfFile> filtered = new ArrayList<>();
            for (PdfFile file : allFiles) {
                if (favMgr.isFavorite(file)) {
                    filtered.add(file);
                }
            }
            return filtered;
        }
        List<PdfFile> filtered = new ArrayList<>();
        for (PdfFile file : allFiles) {
            String fileFolder = getFolderForPdf(file);
            if (folder.equalsIgnoreCase(fileFolder)) {
                filtered.add(file);
            }
        }
        return filtered;
    }
}
