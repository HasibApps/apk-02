package com.example;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.google.android.material.button.MaterialButton;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.net.URLEncoder;

public class GoogleLensActivity extends AppCompatActivity {

    public static final String EXTRA_IMAGE_PATH = "extra_image_path";
    public static final String EXTRA_PAGE_NUMBER = "extra_page_number";

    private ImageView ivLensPageImage;
    private ProgressBar lensScanningProgressBar;
    private TextView tvLensScanStatus;
    private TextView tvExtractedTextContent;
    private MaterialButton btnTopCopyAll;
    private MaterialButton btnChipCopyAll;
    private MaterialButton btnChipTranslate;
    private MaterialButton btnFloatingTranslate;
    private MaterialButton btnChipShareText;
    private MaterialButton btnChipOfficialLens;
    private ImageButton btnOpenExternalLens;
    private ImageButton btnLensClose;
    private View layoutAskAboutImage;

    private String imagePath;
    private int pageNumber = 1;
    private Bitmap pageBitmap;
    private String extractedText = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_lens);

        initViews();
        parseIntent();
        setupListeners();
        loadImageAndRecognize();
    }

    private void initViews() {
        ivLensPageImage = findViewById(R.id.ivLensPageImage);
        lensScanningProgressBar = findViewById(R.id.lensScanningProgressBar);
        tvLensScanStatus = findViewById(R.id.tvLensScanStatus);
        tvExtractedTextContent = findViewById(R.id.tvExtractedTextContent);
        btnTopCopyAll = findViewById(R.id.btnTopCopyAll);
        btnChipCopyAll = findViewById(R.id.btnChipCopyAll);
        btnChipTranslate = findViewById(R.id.btnChipTranslate);
        btnFloatingTranslate = findViewById(R.id.btnFloatingTranslate);
        btnChipShareText = findViewById(R.id.btnChipShareText);
        btnChipOfficialLens = findViewById(R.id.btnChipOfficialLens);
        btnOpenExternalLens = findViewById(R.id.btnOpenExternalLens);
        btnLensClose = findViewById(R.id.btnLensClose);
        layoutAskAboutImage = findViewById(R.id.layoutAskAboutImage);
    }

    private void parseIntent() {
        Intent intent = getIntent();
        if (intent != null) {
            imagePath = intent.getStringExtra(EXTRA_IMAGE_PATH);
            pageNumber = intent.getIntExtra(EXTRA_PAGE_NUMBER, 1);
        }
    }

    private void setupListeners() {
        btnLensClose.setOnClickListener(v -> finish());

        // Copy All Text Action
        View.OnClickListener copyAllAction = v -> copyTextToClipboard();
        btnTopCopyAll.setOnClickListener(copyAllAction);
        btnChipCopyAll.setOnClickListener(copyAllAction);

        // Translate Action
        View.OnClickListener translateAction = v -> translateExtractedText();
        btnFloatingTranslate.setOnClickListener(translateAction);
        btnChipTranslate.setOnClickListener(translateAction);

        // Share Text
        btnChipShareText.setOnClickListener(v -> shareExtractedText());

        // Open in official Google Lens app (strictly using safe lens-specific intent)
        View.OnClickListener officialLensAction = v -> openInOfficialLensSafely();
        btnOpenExternalLens.setOnClickListener(officialLensAction);
        btnChipOfficialLens.setOnClickListener(officialLensAction);

        layoutAskAboutImage.setOnClickListener(v -> copyTextToClipboard());
    }

    private void loadImageAndRecognize() {
        if (TextUtils.isEmpty(imagePath)) {
            Toast.makeText(this, "ইমেজ পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        File imgFile = new File(imagePath);
        if (!imgFile.exists()) {
            Toast.makeText(this, "ইমেজ ফাইল অনুপস্থিত", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        pageBitmap = BitmapFactory.decodeFile(imagePath);
        if (pageBitmap == null) {
            Toast.makeText(this, "ইমেজ ডিকোড করতে সমস্যা", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        ivLensPageImage.setImageBitmap(pageBitmap);
        lensScanningProgressBar.setVisibility(View.VISIBLE);
        tvLensScanStatus.setText("স্ক্যান করা হচ্ছে...");
        tvExtractedTextContent.setText("Google Lens টেক্সট স্ক্যান করছে...");

        // Perform ML Kit on-device Text Recognition
        try {
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            InputImage inputImage = InputImage.fromBitmap(pageBitmap, 0);

            recognizer.process(inputImage)
                    .addOnSuccessListener(visionText -> {
                        lensScanningProgressBar.setVisibility(View.GONE);
                        extractedText = visionText.getText();
                        if (TextUtils.isEmpty(extractedText)) {
                            tvLensScanStatus.setText("কোনো টেক্সট পাওয়া যায়নি");
                            tvExtractedTextContent.setText("এই পৃষ্ঠায় কোনো টেক্সট শনাক্ত করা যায়নি।");
                        } else {
                            tvLensScanStatus.setText("স্ক্যান সম্পন্ন (" + extractedText.length() + " অক্ষর)");
                            tvExtractedTextContent.setText(extractedText);
                        }
                    })
                    .addOnFailureListener(e -> {
                        lensScanningProgressBar.setVisibility(View.GONE);
                        tvLensScanStatus.setText("স্ক্যানিং সম্পন্ন হয়নি");
                        tvExtractedTextContent.setText("টেক্সট শনাক্ত করতে সমস্যা হয়েছে।");
                    });
        } catch (Exception e) {
            e.printStackTrace();
            lensScanningProgressBar.setVisibility(View.GONE);
            tvLensScanStatus.setText("স্ক্যানার চালু সম্ভব হয়নি");
            tvExtractedTextContent.setText("স্ক্যানার চালাতে সমস্যা হয়েছে।");
        }
    }

    private void copyTextToClipboard() {
        if (TextUtils.isEmpty(extractedText)) {
            Toast.makeText(this, "কপি করার মতো টেক্সট পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText("Google Lens OCR Text", extractedText);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "পেজের সকল টেক্সট ক্লিপবোর্ডে কপি করা হয়েছে!", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareExtractedText() {
        if (TextUtils.isEmpty(extractedText)) {
            Toast.makeText(this, "শেয়ার করার মতো টেক্সট নেই", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, extractedText);
        startActivity(Intent.createChooser(shareIntent, "টেক্সট শেয়ার করুন"));
    }

    private void translateExtractedText() {
        if (TextUtils.isEmpty(extractedText)) {
            Toast.makeText(this, "অনুবাদ করার টেক্সট নেই", Toast.LENGTH_SHORT).show();
            return;
        }

        // Copy text first
        copyTextToClipboard();

        // Launch Google Translate directly if available, or web translate
        try {
            String query = URLEncoder.encode(extractedText.substring(0, Math.min(extractedText.length(), 500)), "UTF-8");
            Intent translateIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://translate.google.com/?sl=auto&tl=en&text=" + query));
            startActivity(translateIntent);
        } catch (Exception e) {
            Toast.makeText(this, "টেক্সট কপি করা হয়েছে", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Launch official Google Lens safely without triggering "Save to Collections" dialog
     */
    private void openInOfficialLensSafely() {
        if (TextUtils.isEmpty(imagePath)) return;
        File file = new File(imagePath);
        if (!file.exists()) return;

        Uri contentUri = FileProvider.getUriForFile(this, PdfUtils.FILE_PROVIDER_AUTHORITY, file);
        PackageManager pm = getPackageManager();

        // 1. Google Lens direct package and launcher activity
        try {
            Intent lensDirect = new Intent(Intent.ACTION_SEND);
            lensDirect.setType("image/*");
            lensDirect.putExtra(Intent.EXTRA_STREAM, contentUri);
            lensDirect.setComponent(new ComponentName("com.google.ar.lens", "com.google.vr.apps.ornament.app.lens.LensLauncherActivity"));
            lensDirect.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            if (lensDirect.resolveActivity(pm) != null) {
                startActivity(lensDirect);
                return;
            }
        } catch (Exception ignored) {}

        // 2. Google Lens VIEW_ACTION
        try {
            Intent lensView = new Intent("com.google.ar.lens.VIEW_ACTION");
            lensView.setDataAndType(contentUri, "image/*");
            lensView.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            if (lensView.resolveActivity(pm) != null) {
                startActivity(lensView);
                return;
            }
        } catch (Exception ignored) {}

        // 3. Google App specific Lens activities (DO NOT send generic ACTION_SEND to quicksearchbox!)
        String[] lensActivities = new String[] {
                "com.google.android.apps.search.lens.LensShareActivity",
                "com.google.android.apps.search.lens.LensActivity",
                "com.google.android.apps.gsa.staticplugins.opa.lens.OpaLensActivity"
        };
        for (String act : lensActivities) {
            try {
                Intent gIntent = new Intent(Intent.ACTION_SEND);
                gIntent.setType("image/*");
                gIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                gIntent.setComponent(new ComponentName("com.google.android.googlequicksearchbox", act));
                gIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                if (gIntent.resolveActivity(pm) != null) {
                    startActivity(gIntent);
                    return;
                }
            } catch (Exception ignored) {}
        }

        // 4. Default: All text is already extracted and copyable right here in-app!
        copyTextToClipboard();
        Toast.makeText(this, "ইন-অ্যাপ Google Lens এ পেজের সকল টেক্সট কপি করা হয়েছে", Toast.LENGTH_SHORT).show();
    }
}
