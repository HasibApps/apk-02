package com.example;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/**
 * Invisible, split-second activity. Android only lets the app that currently has window focus
 * read the clipboard, so after Google Lens has copied the text we flash this activity, read the
 * clipboard, hand the text back and close - the user just sees Lens again.
 */
public class ClipboardGrabActivity extends Activity {

    public interface Callback { void onText(String text); }

    /** Set by the caller right before {@link #launch(Context)}. */
    static volatile Callback pending;

    public static void launch(Context ctx) {
        Intent i = new Intent(ctx, ClipboardGrabActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        ctx.startActivity(i);
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean delivered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);
        // Safety net: if focus never arrives, report "nothing" and close.
        handler.postDelayed(() -> deliver(""), 2500);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && !delivered) {
            deliver(readClipboard());
        }
    }

    private String readClipboard() {
        try {
            ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cb == null || !cb.hasPrimaryClip()) return "";
            ClipData clip = cb.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return "";
            CharSequence cs = clip.getItemAt(0).coerceToText(this);
            return cs == null ? "" : cs.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void deliver(String text) {
        if (delivered) return;
        delivered = true;
        handler.removeCallbacksAndMessages(null);
        Callback cb = pending;
        pending = null;
        if (cb != null) cb.onText(text);
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (!delivered) {
            delivered = true;
            Callback cb = pending;
            pending = null;
            if (cb != null) cb.onText("");
        }
        super.onDestroy();
    }
}
