package com.example;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.DialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PdfNotesDialog extends DialogFragment {

    public interface OnJumpToPageListener {
        void onJumpToPage(int pageNumber);
    }

    private static final String ARG_PDF_ID = "arg_pdf_id";
    private static final String ARG_PDF_NAME = "arg_pdf_name";

    private String pdfId;
    private String pdfName;
    private PdfNotesManager notesManager;
    private OnJumpToPageListener jumpListener;

    // Top Navigation Tabs
    private MaterialButton btnTabUnlimited;
    private MaterialButton btnTabChapters;
    private View layoutUnlimitedNotePage;
    private View layoutChapterIndexPage;

    // Unlimited Note Views
    private ScrollView scrollViewUnlimited;
    private EditText etUnlimitedNotes;
    private View layoutFormulaViewContainer;
    private WebView wvFormulaPreview;
    private MaterialButton btnUndoUnlimited;
    private MaterialButton btnRedoUnlimited;
    private MaterialButton btnScrollTop;
    private MaterialButton btnScrollBottom;
    private MaterialButton btnCopyAllUnlimited;
    private MaterialButton btnDownloadTxtUnlimited;
    private MaterialButton btnToggleFormulaView;
    private MaterialButton btnUnlimitedAddPage;
    private MaterialButton btnUnlimitedSmartFormat;
    private LinearLayout layoutSymbolButtons;
    private TextUndoRedoHelper undoRedoHelper;
    private boolean isFormulaViewActive = false;

    // Chapter Index (2-Column) Views
    private EditText etNotesCol1;
    private EditText etNotesCol2;
    private EditText etNotesContent;
    private View layoutTwoColumns;
    private View layoutSingleColumn;
    private ScrollView scrollViewNotes;
    private TextView tvFontSizeValue;
    private TextView tvUnlimitedFontSizeValue;
    private MaterialButton btnToggleColumnMode;

    private EditText lastFocusedChapterEditText = null;
    private float currentFontSize = 12.5f;
    private boolean isTwoColumn = true;
    private boolean isUpdatingSpans = false;
    private boolean isFormattingFormulas = false;

    // Pattern matches: পৃষ্ঠা: 42, পৃষ্ঠা= 42, পৃষ্ঠা 42, (পৃষ্ঠা= ৪২), Page 42, page: 42, etc.
    private static final Pattern PAGE_REF_PATTERN =
            Pattern.compile("(?:পৃষ্ঠা|[Pp]age|[Pp]\\.)\\s*[:=\\-]??\\s*([0-9০-৯]+)");

    public static class PageNumberSpan {
        private final int pageNumber;
        public PageNumberSpan(int pageNumber) {
            this.pageNumber = pageNumber;
        }
        public int getPageNumber() {
            return pageNumber;
        }
    }

    public static class PageColorSpan extends ForegroundColorSpan {
        public PageColorSpan(int color) {
            super(color);
        }
    }

    public static class PageUnderlineSpan extends UnderlineSpan {
    }

    public static class PageBoldSpan extends StyleSpan {
        public PageBoldSpan() {
            super(Typeface.BOLD);
        }
    }

    public static PdfNotesDialog newInstance(String pdfId, String pdfName) {
        PdfNotesDialog dialog = new PdfNotesDialog();
        Bundle args = new Bundle();
        args.putString(ARG_PDF_ID, pdfId);
        args.putString(ARG_PDF_NAME, pdfName);
        dialog.setArguments(args);
        return dialog;
    }

    public void setOnJumpToPageListener(OnJumpToPageListener listener) {
        this.jumpListener = listener;
    }

    private Runnable onDismissCallback;

    /** Called after the dialog is dismissed (used by the stand-alone Lens note screen). */
    public void setOnDismissCallback(Runnable callback) {
        this.onDismissCallback = callback;
    }

    @Override
    public void onDismiss(@NonNull android.content.DialogInterface dialog) {
        super.onDismiss(dialog);
        if (onDismissCallback != null) onDismissCallback.run();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
        if (getArguments() != null) {
            pdfId = getArguments().getString(ARG_PDF_ID, "default_pdf");
            pdfName = getArguments().getString(ARG_PDF_NAME, "Document Notes");
        }
        notesManager = new PdfNotesManager(requireContext());
        currentFontSize = notesManager.getNoteFontSize();
        isTwoColumn = notesManager.isTwoColumnMode();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_pdf_notes, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton btnNotesClose = view.findViewById(R.id.btnNotesClose);
        TextView tvNotesTitle = view.findViewById(R.id.tvNotesTitle);
        MaterialButton btnNotesClearAll = view.findViewById(R.id.btnNotesClearAll);
        MaterialButton btnNotesSave = view.findViewById(R.id.btnNotesSave);

        // Tabs
        btnTabUnlimited = view.findViewById(R.id.btnTabUnlimited);
        btnTabChapters = view.findViewById(R.id.btnTabChapters);
        layoutUnlimitedNotePage = view.findViewById(R.id.layoutUnlimitedNotePage);
        layoutChapterIndexPage = view.findViewById(R.id.layoutChapterIndexPage);

        // Unlimited Note Views
        scrollViewUnlimited = view.findViewById(R.id.scrollViewUnlimited);
        etUnlimitedNotes = view.findViewById(R.id.etUnlimitedNotes);
        layoutFormulaViewContainer = view.findViewById(R.id.layoutFormulaViewContainer);
        wvFormulaPreview = view.findViewById(R.id.wvFormulaPreview);
        btnUndoUnlimited = view.findViewById(R.id.btnUndoUnlimited);
        btnRedoUnlimited = view.findViewById(R.id.btnRedoUnlimited);
        btnScrollTop = view.findViewById(R.id.btnScrollTop);
        btnScrollBottom = view.findViewById(R.id.btnScrollBottom);
        btnCopyAllUnlimited = view.findViewById(R.id.btnCopyAllUnlimited);
        btnDownloadTxtUnlimited = view.findViewById(R.id.btnDownloadTxtUnlimited);
        btnToggleFormulaView = view.findViewById(R.id.btnToggleFormulaView);
        btnUnlimitedAddPage = view.findViewById(R.id.btnUnlimitedAddPage);
        btnUnlimitedSmartFormat = view.findViewById(R.id.btnUnlimitedSmartFormat);
        layoutSymbolButtons = view.findViewById(R.id.layoutSymbolButtons);

        // Chapter Index Views
        View btnFontSizeDecrease = view.findViewById(R.id.btnFontSizeDecrease);
        tvFontSizeValue = view.findViewById(R.id.tvFontSizeValue);
        View btnFontSizeIncrease = view.findViewById(R.id.btnFontSizeIncrease);
        btnToggleColumnMode = view.findViewById(R.id.btnToggleColumnMode);
        MaterialButton btnResetDefault10 = view.findViewById(R.id.btnResetDefault10);
        layoutTwoColumns = view.findViewById(R.id.layoutTwoColumns);
        layoutSingleColumn = view.findViewById(R.id.layoutSingleColumn);
        etNotesCol1 = view.findViewById(R.id.etNotesCol1);
        etNotesCol2 = view.findViewById(R.id.etNotesCol2);
        etNotesContent = view.findViewById(R.id.etNotesContent);
        scrollViewNotes = view.findViewById(R.id.scrollViewNotes);
        MaterialButton btnNotesAddChapter = view.findViewById(R.id.btnNotesAddChapter);
        MaterialButton btnNotesAddPageTag = view.findViewById(R.id.btnNotesAddPageTag);

        // Apply Google Font
        Typeface bengaliFont = ResourcesCompat.getFont(requireContext(), R.font.noto_serif_bengali);
        if (bengaliFont != null) {
            tvNotesTitle.setTypeface(bengaliFont, Typeface.BOLD);
            btnNotesClearAll.setTypeface(bengaliFont);
            btnNotesSave.setTypeface(bengaliFont, Typeface.BOLD);
            btnTabUnlimited.setTypeface(bengaliFont, Typeface.BOLD);
            btnTabChapters.setTypeface(bengaliFont);
            etUnlimitedNotes.setTypeface(bengaliFont);
            etNotesCol1.setTypeface(bengaliFont);
            etNotesCol2.setTypeface(bengaliFont);
            etNotesContent.setTypeface(bengaliFont);
            btnNotesAddChapter.setTypeface(bengaliFont, Typeface.BOLD);
            btnNotesAddPageTag.setTypeface(bengaliFont, Typeface.BOLD);
            btnUnlimitedAddPage.setTypeface(bengaliFont, Typeface.BOLD);
            btnUnlimitedSmartFormat.setTypeface(bengaliFont, Typeface.BOLD);
            btnToggleColumnMode.setTypeface(bengaliFont);
            btnResetDefault10.setTypeface(bengaliFont);
        }

        tvNotesTitle.setText(pdfName != null ? "নোট: " + PdfUtils.cleanPdfName(pdfName) : "নোট ও ইনডেক্স");

        // 1. SETUP TAB SWITCHING - By default, AUTO-OPEN UNLIMITED NOTE PAGE (Requirement 2)
        setupTabSwitching();

        // 2. SETUP UNLIMITED NOTE (Requirement 1 & 2 & 3)
        setupUnlimitedNote(view);

        // 3. SETUP CHAPTER INDEX (2-Column & Single-Column Mode)
        setupChapterIndex(btnFontSizeDecrease, btnFontSizeIncrease, btnToggleColumnMode, btnResetDefault10, btnNotesAddChapter, btnNotesAddPageTag);

        // Top bar action buttons
        btnNotesClose.setOnClickListener(v -> dismiss());
        btnNotesSave.setOnClickListener(v -> {
            saveAllNotes();
            Toast.makeText(requireContext(), "✓ সকল নোট সংরক্ষণ করা হয়েছে", Toast.LENGTH_SHORT).show();
            dismiss();
        });

        btnNotesClearAll.setOnClickListener(v -> {
            boolean isUnlimitedTab = layoutUnlimitedNotePage.getVisibility() == View.VISIBLE;
            String msg = isUnlimitedTab
                    ? "আপনি কি এই PDF-এর আনলিমিটেড নোট মুছে ফেলতে চান?"
                    : "আপনি কি অধ্যায় ইনডেক্সের নোট মুছে ফেলতে চান?";

            new MaterialAlertDialogBuilder(requireContext())
                    .setTitle("নোট মুছে ফেলা")
                    .setMessage(msg)
                    .setPositiveButton("মুছে ফেলুন", (dialog, which) -> {
                        if (isUnlimitedTab) {
                            etUnlimitedNotes.setText("");
                            notesManager.saveUnlimitedNoteForPdf(pdfId, "");
                            notesManager.clearPastedPages(pdfId);
                            Toast.makeText(requireContext(), "আনলিমিটেড নোট মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show();
                        } else {
                            notesManager.clearNoteForPdf(pdfId);
                            etNotesCol1.setText("");
                            etNotesCol2.setText("");
                            etNotesContent.setText("");
                            updateSpans(etNotesCol1.getText());
                            updateSpans(etNotesCol2.getText());
                            updateSpans(etNotesContent.getText());
                            Toast.makeText(requireContext(), "অধ্যায় নোট মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("বাতিল", null)
                    .show();
        });
    }

    // -------------------------------------------------------------
    // TAB SWITCHING (Auto opens Unlimited Note by default)
    // -------------------------------------------------------------
    private void setupTabSwitching() {
        btnTabUnlimited.setOnClickListener(v -> switchTab(true));
        btnTabChapters.setOnClickListener(v -> switchTab(false));

        // Default: Open Unlimited Note Page
        switchTab(true);
    }

    private void switchTab(boolean showUnlimited) {
        int primaryColor = ContextCompat.getColor(requireContext(), R.color.primary);
        int onPrimaryColor = ContextCompat.getColor(requireContext(), R.color.on_primary);
        int secondaryTextColor = ContextCompat.getColor(requireContext(), R.color.text_secondary);

        if (showUnlimited) {
            layoutUnlimitedNotePage.setVisibility(View.VISIBLE);
            layoutChapterIndexPage.setVisibility(View.GONE);

            btnTabUnlimited.setBackgroundTintList(ColorStateList.valueOf(primaryColor));
            btnTabUnlimited.setTextColor(onPrimaryColor);
            btnTabUnlimited.setIconTint(ColorStateList.valueOf(onPrimaryColor));

            btnTabChapters.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
            btnTabChapters.setTextColor(secondaryTextColor);
            btnTabChapters.setIconTint(ColorStateList.valueOf(secondaryTextColor));
            btnTabChapters.setStrokeColor(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.divider)));
        } else {
            layoutUnlimitedNotePage.setVisibility(View.GONE);
            layoutChapterIndexPage.setVisibility(View.VISIBLE);

            btnTabChapters.setBackgroundTintList(ColorStateList.valueOf(primaryColor));
            btnTabChapters.setTextColor(onPrimaryColor);
            btnTabChapters.setIconTint(ColorStateList.valueOf(onPrimaryColor));

            btnTabUnlimited.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
            btnTabUnlimited.setTextColor(secondaryTextColor);
            btnTabUnlimited.setIconTint(ColorStateList.valueOf(secondaryTextColor));
            btnTabUnlimited.setStrokeColor(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.divider)));
        }
    }

    // -------------------------------------------------------------
    // UNLIMITED NOTE IMPLEMENTATION (Requirement 1, 2, 3)
    // -------------------------------------------------------------
    private void setupUnlimitedNote(View view) {
        // Load saved unlimited note for this specific PDF
        String savedUnlimited = notesManager.getUnlimitedNoteForPdf(pdfId);
        etUnlimitedNotes.setText(savedUnlimited);
        updateSpans(etUnlimitedNotes.getText());

        // Setup Undo / Redo Helper
        undoRedoHelper = new TextUndoRedoHelper(etUnlimitedNotes);
        undoRedoHelper.setListener((canUndo, canRedo) -> {
            btnUndoUnlimited.setEnabled(canUndo);
            btnRedoUnlimited.setEnabled(canRedo);
            btnUndoUnlimited.setAlpha(canUndo ? 1.0f : 0.4f);
            btnRedoUnlimited.setAlpha(canRedo ? 1.0f : 0.4f);
        });

        btnUndoUnlimited.setOnClickListener(v -> undoRedoHelper.undo());
        btnRedoUnlimited.setOnClickListener(v -> undoRedoHelper.redo());

        // Scroll to Top (এক ক্লিকেই টেক্সটের সবার উপরে চলে যাওয়া)
        btnScrollTop.setOnClickListener(v -> {
            scrollViewUnlimited.smoothScrollTo(0, 0);
            etUnlimitedNotes.setSelection(0);
        });

        // Scroll to Bottom (এক ক্লিকেই টেক্সটের সবার নিচে চলে যাওয়া)
        btnScrollBottom.setOnClickListener(v -> {
            scrollViewUnlimited.post(() -> {
                scrollViewUnlimited.fullScroll(View.FOCUS_DOWN);
                etUnlimitedNotes.setSelection(etUnlimitedNotes.getText().length());
            });
        });

        // Copy All (সকল টেক্সট কপি)
        btnCopyAllUnlimited.setOnClickListener(v -> {
            String allText = etUnlimitedNotes.getText().toString();
            if (allText.trim().isEmpty()) {
                Toast.makeText(requireContext(), "কপি করার জন্য কোনো টেক্সট নেই", Toast.LENGTH_SHORT).show();
                return;
            }
            ClipboardManager cb = (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
            if (cb != null) {
                cb.setPrimaryClip(ClipData.newPlainText("PDF Unlimited Note", allText));
                Toast.makeText(requireContext(), "✓ সকল নোট কপি করা হয়েছে!", Toast.LENGTH_SHORT).show();
            }
        });

        // Download TXT Panel (ডাউনলোড প্যানেল)
        btnDownloadTxtUnlimited.setOnClickListener(v -> showDownloadTxtDialog());

        // Formula View Toggle (সমীকরণ ও সূত্র ভিউ - MathJax/KaTeX Render)
        btnToggleFormulaView.setOnClickListener(v -> toggleFormulaView());

        // Quick Math & Chemistry Symbol Bar
        populateSymbolBar();

        // Smart Formula Formatting button
        btnUnlimitedSmartFormat.setOnClickListener(v -> {
            String current = etUnlimitedNotes.getText().toString();
            String formatted = FormulaHelper.formatScientificText(current);
            if (!formatted.equals(current)) {
                etUnlimitedNotes.setText(formatted);
                etUnlimitedNotes.setSelection(formatted.length());
                notesManager.saveUnlimitedNoteForPdf(pdfId, formatted);
                updateSpans(etUnlimitedNotes.getText());
                Toast.makeText(requireContext(), "✓ রসায়ন ও পদার্থ সূত্র সমীকরণ ফরম্যাট হয়েছে", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "সকল সূত্র ইতোমধ্যে সঠিক ফরম্যাটে রয়েছে", Toast.LENGTH_SHORT).show();
            }
        });

        // Setup touch to page link and text watchers
        setupEditorWatcherAndTouch(etUnlimitedNotes, true);

        // Requirement 2: (+ পৃষ্ঠা) Button
        btnUnlimitedAddPage.setOnClickListener(v -> handleUnlimitedAddPageClick());
        btnUnlimitedAddPage.setOnLongClickListener(v -> {
            showResetStartingPageDialog();
            return true;
        });

        View btnUnlimitedFontSizeDecrease = view.findViewById(R.id.btnUnlimitedFontSizeDecrease);
        tvUnlimitedFontSizeValue = view.findViewById(R.id.tvUnlimitedFontSizeValue);
        View btnUnlimitedFontSizeIncrease = view.findViewById(R.id.btnUnlimitedFontSizeIncrease);

        if (btnUnlimitedFontSizeDecrease != null) {
            btnUnlimitedFontSizeDecrease.setOnClickListener(v -> {
                if (currentFontSize > 9.5f) applyFontSize(currentFontSize - 1.0f);
            });
        }
        if (btnUnlimitedFontSizeIncrease != null) {
            btnUnlimitedFontSizeIncrease.setOnClickListener(v -> {
                if (currentFontSize < 22.0f) applyFontSize(currentFontSize + 1.0f);
            });
        }

        // Apply current font size
        applyFontSize(currentFontSize);
    }

    /**
     * Requirement 2: (+ পৃষ্ঠা) Button Click Handler
     * 1st time: Shows an input box where user enters e.g. 100 or 11.
     * Inserts bold text (পৃষ্ঠা= ১০০) into the editor.
     * Subsequent times: automatically increments by 1 (101, 102...) and inserts bold (পৃষ্ঠা= ১০১)...
     */
    private void handleUnlimitedAddPageClick() {
        int lastPage = notesManager.getLastUnlimitedPageForPdf(pdfId);
        if (lastPage <= 0) {
            // First time: Prompt user for starting page number
            showStartingPageInputDialog();
        } else {
            // Subsequent clicks: Auto-increment!
            int nextPage = lastPage + 1;
            insertFormattedPageTag(nextPage);
            notesManager.saveLastUnlimitedPageForPdf(pdfId, nextPage);
        }
    }

    private void showStartingPageInputDialog() {
        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_jump_to_page, null);
        EditText etPageInput = dialogView.findViewById(R.id.etTargetPageNumber);
        TextView tvTitle = dialogView.findViewById(R.id.tvJumpTitle);
        TextView tvSubtitle = dialogView.findViewById(R.id.tvJumpSubtitle);

        if (tvTitle != null) tvTitle.setText("(+) পৃষ্ঠা নম্বর নির্ধারণ করুন");
        if (tvSubtitle != null) tvSubtitle.setText("শুরুর পৃষ্ঠা নম্বরটি লিখুন (যেমন: ১০০ বা ১১)। এরপর থেকে স্বয়ংক্রিয়ভাবে পরবর্তী সংখ্যা যুক্ত হবে:");
        if (etPageInput != null) {
            etPageInput.setHint("১০০");
            etPageInput.setText("১০০");
            etPageInput.selectAll();
        }

        new MaterialAlertDialogBuilder(requireContext())
                .setView(dialogView)
                .setPositiveButton("যুক্ত করুন", (dialog, which) -> {
                    String input = etPageInput != null ? etPageInput.getText().toString().trim() : "";
                    int pageNum = parsePageNumber(input);
                    if (pageNum <= 0) pageNum = 100;

                    insertFormattedPageTag(pageNum);
                    notesManager.saveLastUnlimitedPageForPdf(pdfId, pageNum);
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void showResetStartingPageDialog() {
        int currentPage = notesManager.getLastUnlimitedPageForPdf(pdfId);
        String currentMsg = currentPage > 0
                ? "বর্তমান পৃষ্ঠা ক্রম: " + PdfNotesManager.toBengaliDigits(currentPage) + "। নতুন শুরুর পৃষ্ঠা নম্বর লিখুন:"
                : "শুরুর পৃষ্ঠা নম্বর লিখুন (যেমন: ১০০ বা ১১):";

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_jump_to_page, null);
        EditText etPageInput = dialogView.findViewById(R.id.etTargetPageNumber);
        TextView tvTitle = dialogView.findViewById(R.id.tvJumpTitle);
        TextView tvSubtitle = dialogView.findViewById(R.id.tvJumpSubtitle);

        if (tvTitle != null) tvTitle.setText("পৃষ্ঠা নম্বর পরিবর্তন / রিসেট");
        if (tvSubtitle != null) tvSubtitle.setText(currentMsg);
        if (etPageInput != null) {
            etPageInput.setHint("১০০");
            etPageInput.setText(currentPage > 0 ? String.valueOf(currentPage) : "১০০");
            etPageInput.selectAll();
        }

        new MaterialAlertDialogBuilder(requireContext())
                .setView(dialogView)
                .setPositiveButton("আপডেট করুন", (dialog, which) -> {
                    String input = etPageInput != null ? etPageInput.getText().toString().trim() : "";
                    int pageNum = parsePageNumber(input);
                    if (pageNum <= 0) pageNum = 100;

                    notesManager.saveLastUnlimitedPageForPdf(pdfId, pageNum);
                    Toast.makeText(requireContext(), "পৃষ্ঠা ক্রম " + PdfNotesManager.toBengaliDigits(pageNum) + " থেকে শুরু হবে", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void insertFormattedPageTag(int pageNum) {
        String bengaliDigits = PdfNotesManager.toBengaliDigits(pageNum);
        String tagText = "\n\n(পৃষ্ঠা= " + bengaliDigits + ")\n";

        etUnlimitedNotes.requestFocus();
        int start = Math.max(etUnlimitedNotes.getSelectionStart(), 0);
        int end = Math.max(etUnlimitedNotes.getSelectionEnd(), 0);
        Editable editable = etUnlimitedNotes.getText();
        if (editable == null) return;

        // If text is empty or cursor at start, don't add leading double newlines
        if (start == 0 && editable.length() == 0) {
            tagText = "(পৃষ্ঠা= " + bengaliDigits + ")\n";
        }

        editable.replace(Math.min(start, end), Math.max(start, end), tagText, 0, tagText.length());
        int newPos = Math.min(start, end) + tagText.length();
        etUnlimitedNotes.setSelection(newPos);

        // Save immediately
        notesManager.saveUnlimitedNoteForPdf(pdfId, editable.toString());
        updateSpans(editable);

        scrollViewUnlimited.post(() -> scrollViewUnlimited.fullScroll(View.FOCUS_DOWN));
        Toast.makeText(requireContext(), "(পৃষ্ঠা= " + bengaliDigits + ") যুক্ত হয়েছে", Toast.LENGTH_SHORT).show();
    }

    /**
     * Requirement 1: Download Panel for .txt notes with editable filename
     */
    private void showDownloadTxtDialog() {
        String noteContent = etUnlimitedNotes.getText().toString();
        if (noteContent.trim().isEmpty()) {
            Toast.makeText(requireContext(), "ডাউনলোড করার মতো কোনো নোট লেখা হয়নি", Toast.LENGTH_SHORT).show();
            return;
        }

        Dialog dialog = new Dialog(requireContext());
        dialog.setContentView(R.layout.dialog_download_note);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        TextInputEditText etDownloadFileName = dialog.findViewById(R.id.etDownloadFileName);
        TextView tvDownloadNoteStats = dialog.findViewById(R.id.tvDownloadNoteStats);
        MaterialButton btnDownloadCancel = dialog.findViewById(R.id.btnDownloadCancel);
        MaterialButton btnDownloadShare = dialog.findViewById(R.id.btnDownloadShare);
        MaterialButton btnDownloadConfirm = dialog.findViewById(R.id.btnDownloadConfirm);

        // Prepopulate default file name from PDF title
        String defaultName = pdfName != null ? PdfUtils.cleanPdfName(pdfName) : "PDF_Note";
        defaultName = defaultName.replaceAll("[^a-zA-Z0-9_\\-\\u0980-\\u09FF]", "_");
        if (defaultName.toLowerCase().endsWith(".pdf")) {
            defaultName = defaultName.substring(0, defaultName.length() - 4);
        }
        String initialFileName = defaultName + "_Note.txt";
        etDownloadFileName.setText(initialFileName);
        etDownloadFileName.setSelection(initialFileName.length());

        // Stats
        int charCount = noteContent.length();
        int wordCount = noteContent.trim().isEmpty() ? 0 : noteContent.trim().split("\\s+").length;
        tvDownloadNoteStats.setText("মোট বর্ণ: " + charCount + " | মোট শব্দ: " + wordCount);

        btnDownloadCancel.setOnClickListener(v -> dialog.dismiss());

        btnDownloadShare.setOnClickListener(v -> {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, etDownloadFileName.getText().toString());
            shareIntent.putExtra(Intent.EXTRA_TEXT, noteContent);
            startActivity(Intent.createChooser(shareIntent, "Share Note via"));
            dialog.dismiss();
        });

        btnDownloadConfirm.setOnClickListener(v -> {
            String fileName = etDownloadFileName.getText() != null ? etDownloadFileName.getText().toString().trim() : "";
            if (fileName.isEmpty()) {
                fileName = "Note_" + System.currentTimeMillis() + ".txt";
            }
            if (!fileName.toLowerCase().endsWith(".txt")) {
                fileName += ".txt";
            }

            boolean success = saveNoteAsTxtFile(fileName, noteContent);
            if (success) {
                Toast.makeText(requireContext(), "✓ ডাউনলোড সফল: " + fileName + "\n(Downloads ফোল্ডারে সংরক্ষিত)", Toast.LENGTH_LONG).show();
                dialog.dismiss();
            } else {
                Toast.makeText(requireContext(), "ফাইল ডাউনলোড করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private boolean saveNoteAsTxtFile(String fileName, String content) {
        try {
            Context context = requireContext();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = context.getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues);
                if (uri != null) {
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out != null) {
                            out.write(content.getBytes(StandardCharsets.UTF_8));
                            out.flush();
                            return true;
                        }
                    }
                }
            } else {
                File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloadsDir.exists()) downloadsDir.mkdirs();
                File targetFile = new File(downloadsDir, fileName);
                try (FileOutputStream fos = new FileOutputStream(targetFile)) {
                    fos.write(content.getBytes(StandardCharsets.UTF_8));
                    fos.flush();
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Requirement 3: Toggle Formula View (Render Mode with MathJax / KaTeX)
     */
    private void toggleFormulaView() {
        isFormulaViewActive = !isFormulaViewActive;
        if (isFormulaViewActive) {
            scrollViewUnlimited.setVisibility(View.GONE);
            layoutFormulaViewContainer.setVisibility(View.VISIBLE);
            btnToggleFormulaView.setText("এডিটর ভিউ");
            btnToggleFormulaView.setIconResource(R.drawable.ic_edit);

            boolean isDark = ThemeManager.isDarkMode(requireContext());
            String html = FormulaHelper.generateHtmlForFormulas(etUnlimitedNotes.getText().toString(), isDark);
            wvFormulaPreview.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        } else {
            layoutFormulaViewContainer.setVisibility(View.GONE);
            scrollViewUnlimited.setVisibility(View.VISIBLE);
            btnToggleFormulaView.setText("সমীকরণ ভিউ");
            btnToggleFormulaView.setIconResource(R.drawable.ic_functions);
        }
    }

    /**
     * Requirement 3: Quick Scientific Symbol Bar (Math, Chemistry, Physics)
     */
    private void populateSymbolBar() {
        if (layoutSymbolButtons == null) return;
        layoutSymbolButtons.removeAllViews();

        String[] symbols = {
                // Chemistry
                "H₂O", "CO₂", "→", "⇌", "↑", "↓", "⁺", "⁻", "₂", "₃", "₄",
                // Physics & Math
                "²", "³", "√", "π", "θ", "λ", "Δ", "α", "β", "ω", "±", "×", "÷", "∫", "∑", "∞", "≠", "≈", "½", "°",
                // Common Physics Templates
                "E=mc²", "F=ma", "v²=u²+2as", "s=ut+½at²"
        };

        for (String sym : symbols) {
            MaterialButton btn = new MaterialButton(requireContext(), null, com.google.android.material.R.attr.borderlessButtonStyle);
            btn.setText(sym);
            btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            btn.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary));
            btn.setPadding(16, 0, 16, 0);
            btn.setInsetTop(0);
            btn.setInsetBottom(0);
            btn.setMinWidth(0);
            btn.setMinimumWidth(0);
            btn.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 32, getResources().getDisplayMetrics())
            ));

            btn.setOnClickListener(v -> insertSymbolAtCursor(sym));
            layoutSymbolButtons.addView(btn);
        }
    }

    private void insertSymbolAtCursor(String symbol) {
        if (isFormulaViewActive) {
            toggleFormulaView(); // Switch back to editor
        }

        etUnlimitedNotes.requestFocus();
        int start = Math.max(etUnlimitedNotes.getSelectionStart(), 0);
        int end = Math.max(etUnlimitedNotes.getSelectionEnd(), 0);
        Editable editable = etUnlimitedNotes.getText();
        if (editable != null) {
            editable.replace(Math.min(start, end), Math.max(start, end), symbol, 0, symbol.length());
            etUnlimitedNotes.setSelection(Math.min(start, end) + symbol.length());
        }
    }

    // -------------------------------------------------------------
    // CHAPTER INDEX IMPLEMENTATION (2-Columns & 1-Column)
    // -------------------------------------------------------------
    private void setupChapterIndex(View btnFontSizeDecrease, View btnFontSizeIncrease,
                                  MaterialButton btnToggleColumnMode, MaterialButton btnResetDefault10,
                                  MaterialButton btnNotesAddChapter, MaterialButton btnNotesAddPageTag) {

        String savedCol1 = notesManager.getNoteCol1ForPdf(pdfId);
        String savedCol2 = notesManager.getNoteCol2ForPdf(pdfId);
        etNotesCol1.setText(savedCol1);
        etNotesCol2.setText(savedCol2);

        String combined = savedCol1 + "\n\n" + savedCol2;
        etNotesContent.setText(combined);

        lastFocusedChapterEditText = etNotesCol1;
        applyFontSize(currentFontSize);
        updateColumnModeUI();

        etNotesCol1.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) lastFocusedChapterEditText = etNotesCol1;
        });
        etNotesCol2.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) lastFocusedChapterEditText = etNotesCol2;
        });
        etNotesContent.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) lastFocusedChapterEditText = etNotesContent;
        });

        setupEditorWatcherAndTouch(etNotesCol1, false);
        setupEditorWatcherAndTouch(etNotesCol2, false);
        setupEditorWatcherAndTouch(etNotesContent, false);

        updateSpans(etNotesCol1.getText());
        updateSpans(etNotesCol2.getText());
        updateSpans(etNotesContent.getText());

        btnFontSizeDecrease.setOnClickListener(v -> {
            if (currentFontSize > 9.5f) applyFontSize(currentFontSize - 1.0f);
        });

        btnFontSizeIncrease.setOnClickListener(v -> {
            if (currentFontSize < 22.0f) applyFontSize(currentFontSize + 1.0f);
        });

        btnToggleColumnMode.setOnClickListener(v -> {
            isTwoColumn = !isTwoColumn;
            notesManager.setTwoColumnMode(isTwoColumn);
            if (!isTwoColumn) {
                String col1 = etNotesCol1.getText().toString().trim();
                String col2 = etNotesCol2.getText().toString().trim();
                String merged = col1 + (!col2.isEmpty() ? "\n\n" + col2 : "");
                etNotesContent.setText(merged);
                updateSpans(etNotesContent.getText());
            } else {
                syncSingleToTwoColumns();
            }
            updateColumnModeUI();
        });

        btnResetDefault10.setOnClickListener(v -> {
            new MaterialAlertDialogBuilder(requireContext())
                    .setTitle("ডিফল্ট ১০ অধ্যায় রিসেট")
                    .setMessage("আপনি কি ১০টি অধ্যায়ের ডিফল্ট ফরম্যাট ফিরিয়ে আনতে চান?")
                    .setPositiveButton("হ্যাঁ, রিসেট করুন", (dialog, which) -> {
                        String defCol1 = PdfNotesManager.generateChapters(1, 5);
                        String defCol2 = PdfNotesManager.generateChapters(6, 5);
                        etNotesCol1.setText(defCol1);
                        etNotesCol2.setText(defCol2);
                        etNotesContent.setText(defCol1 + "\n\n" + defCol2);
                        notesManager.saveTwoColumnNotes(pdfId, defCol1, defCol2);
                        updateSpans(etNotesCol1.getText());
                        updateSpans(etNotesCol2.getText());
                        updateSpans(etNotesContent.getText());
                        Toast.makeText(requireContext(), "১০টি অধ্যায় তৈরি হয়েছে", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("বাতিল", null)
                    .show();
        });

        btnNotesAddChapter.setOnClickListener(v -> {
            int nextChapter = calculateNextChapterNumber();
            String newChapterTemplate = PdfNotesManager.generateChapterTemplate(nextChapter);

            EditText target = isTwoColumn ? (lastFocusedChapterEditText != null ? lastFocusedChapterEditText : etNotesCol2) : etNotesContent;
            String current = target.getText().toString();
            String updated = current.trim().isEmpty() ? newChapterTemplate.trim() : current + newChapterTemplate;

            target.setText(updated);
            target.setSelection(updated.length());
            saveAllNotes();
            updateSpans(target.getText());

            scrollViewNotes.post(() -> scrollViewNotes.fullScroll(View.FOCUS_DOWN));
            Toast.makeText(requireContext(), "অধ্যায় " + nextChapter + " যোগ করা হয়েছে", Toast.LENGTH_SHORT).show();
        });

        btnNotesAddPageTag.setOnClickListener(v -> insertChapterPageTag());
    }

    private void applyFontSize(float sizeSp) {
        currentFontSize = Math.max(9.5f, Math.min(22.0f, sizeSp));
        String formattedSp = String.format(Locale.getDefault(), "%.0fsp", currentFontSize);
        if (tvFontSizeValue != null) {
            tvFontSizeValue.setText(formattedSp);
        }
        if (tvUnlimitedFontSizeValue != null) {
            tvUnlimitedFontSizeValue.setText(formattedSp);
        }
        if (etUnlimitedNotes != null) etUnlimitedNotes.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSize);
        if (etNotesCol1 != null) etNotesCol1.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSize);
        if (etNotesCol2 != null) etNotesCol2.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSize);
        if (etNotesContent != null) etNotesContent.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSize);
        notesManager.saveNoteFontSize(currentFontSize);
    }

    private void updateColumnModeUI() {
        if (isTwoColumn) {
            layoutTwoColumns.setVisibility(View.VISIBLE);
            layoutSingleColumn.setVisibility(View.GONE);
            btnToggleColumnMode.setText("২ কলাম");
            btnToggleColumnMode.setIconResource(R.drawable.ic_view_column);
        } else {
            layoutTwoColumns.setVisibility(View.GONE);
            layoutSingleColumn.setVisibility(View.VISIBLE);
            btnToggleColumnMode.setText("১ কলাম");
            btnToggleColumnMode.setIconResource(R.drawable.ic_note);
        }
    }

    private void syncSingleToTwoColumns() {
        String text = etNotesContent.getText().toString();
        if (text.contains(PdfNotesManager.COLUMN_SPLIT_DELIMITER)) {
            String[] parts = text.split(Pattern.quote(PdfNotesManager.COLUMN_SPLIT_DELIMITER), 2);
            etNotesCol1.setText(parts[0]);
            etNotesCol2.setText(parts.length > 1 ? parts[1] : "");
        } else {
            int ch6Idx = text.indexOf("অধ্যায়:০৬");
            if (ch6Idx == -1) ch6Idx = text.indexOf("অধ্যায়:06");
            if (ch6Idx != -1) {
                etNotesCol1.setText(text.substring(0, ch6Idx).trim());
                etNotesCol2.setText(text.substring(ch6Idx).trim());
            } else {
                etNotesCol1.setText(text);
                if (etNotesCol2.getText().toString().isEmpty()) {
                    etNotesCol2.setText(PdfNotesManager.generateChapters(6, 5));
                }
            }
        }
        updateSpans(etNotesCol1.getText());
        updateSpans(etNotesCol2.getText());
    }

    private void insertChapterPageTag() {
        EditText target = lastFocusedChapterEditText;
        if (target == null) target = isTwoColumn ? etNotesCol1 : etNotesContent;
        if (target == null) return;

        target.requestFocus();
        int start = Math.max(target.getSelectionStart(), 0);
        int end = Math.max(target.getSelectionEnd(), 0);
        Editable editable = target.getText();
        if (editable == null) return;

        String insertText = " পৃষ্ঠা= ";
        editable.replace(Math.min(start, end), Math.max(start, end), insertText, 0, insertText.length());
        int newPos = Math.min(start, end) + insertText.length();
        target.setSelection(newPos);

        try {
            InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(target, InputMethodManager.SHOW_IMPLICIT);
        } catch (Exception ignored) {}

        Toast.makeText(requireContext(), "পৃষ্ঠা= যোগ করা হয়েছে", Toast.LENGTH_SHORT).show();
    }

    private int calculateNextChapterNumber() {
        String combined = (etNotesCol1.getText().toString() + "\n" + etNotesCol2.getText().toString() + "\n" + etNotesContent.getText().toString());
        int count = 0;
        Pattern pattern = Pattern.compile("অধ্যায়\\s*[:：]\\s*([০-৯0-9]+)");
        Matcher matcher = pattern.matcher(combined);
        while (matcher.find()) {
            count++;
        }
        return Math.max(count + 1, 2);
    }

    private void saveAllNotes() {
        // Save unlimited note
        if (etUnlimitedNotes != null) {
            notesManager.saveUnlimitedNoteForPdf(pdfId, etUnlimitedNotes.getText().toString());
        }

        // Save chapters note
        if (isTwoColumn) {
            String c1 = etNotesCol1 != null ? etNotesCol1.getText().toString() : "";
            String c2 = etNotesCol2 != null ? etNotesCol2.getText().toString() : "";
            notesManager.saveTwoColumnNotes(pdfId, c1, c2);
        } else {
            String content = etNotesContent != null ? etNotesContent.getText().toString() : "";
            notesManager.saveNoteForPdf(pdfId, content);
        }
    }

    private void setupEditorWatcherAndTouch(EditText editText, boolean isUnlimitedEditor) {
        if (editText == null) return;

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (s == null) return;

                if (isUnlimitedEditor) {
                    if (!isFormattingFormulas) {
                        String current = s.toString();
                        if (current.contains("^") || current.contains("->") || current.contains("⇌")
                                || current.contains("_") || current.contains("\\") || current.contains("H2O")
                                || current.contains("CO2") || current.contains("H2SO4") || current.contains("<=>")
                                || current.contains("-->") || current.contains("1/2") || current.contains("+/-")) {
                            String formatted = FormulaHelper.formatScientificText(current);
                            if (!formatted.equals(current)) {
                                isFormattingFormulas = true;
                                try {
                                    int cursor = editText.getSelectionStart();
                                    int diff = formatted.length() - current.length();
                                    editText.setText(formatted);
                                    int newPos = Math.max(0, Math.min(cursor + diff, formatted.length()));
                                    editText.setSelection(newPos);
                                    s = editText.getText();
                                } finally {
                                    isFormattingFormulas = false;
                                }
                            }
                        }
                    }
                    notesManager.saveUnlimitedNoteForPdf(pdfId, s != null ? s.toString() : "");
                } else {
                    saveAllNotes();
                }
                updateSpans(s);
            }
        });

        editText.setOnTouchListener(new View.OnTouchListener() {
            private float startX, startY;
            private long startTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getX();
                        startY = event.getY();
                        startTime = System.currentTimeMillis();
                        break;

                    case MotionEvent.ACTION_UP:
                        float diffX = Math.abs(event.getX() - startX);
                        float diffY = Math.abs(event.getY() - startY);
                        long duration = System.currentTimeMillis() - startTime;

                        if (diffX < 25 && diffY < 25 && duration < 350) {
                            int x = (int) event.getX() - editText.getTotalPaddingLeft() + editText.getScrollX();
                            int y = (int) event.getY() - editText.getTotalPaddingTop() + editText.getScrollY();

                            Layout layout = editText.getLayout();
                            if (layout != null) {
                                int line = layout.getLineForVertical(y);
                                if (line >= 0 && line < layout.getLineCount()) {
                                    float lineLeft = layout.getLineLeft(line);
                                    float lineRight = layout.getLineRight(line);

                                    if (x >= lineLeft && x <= lineRight + 20) {
                                        int offset = layout.getOffsetForHorizontal(line, x);
                                        Editable text = editText.getText();
                                        if (text != null && offset >= 0 && offset <= text.length()) {
                                            PageNumberSpan[] spans = text.getSpans(offset, offset, PageNumberSpan.class);
                                            if ((spans == null || spans.length == 0) && offset > 0) {
                                                spans = text.getSpans(offset - 1, offset, PageNumberSpan.class);
                                            }
                                            if (spans != null && spans.length > 0) {
                                                int targetPage = spans[0].getPageNumber();
                                                if (jumpListener != null) {
                                                    jumpListener.onJumpToPage(targetPage);
                                                }
                                                dismiss();
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        break;
                }
                return false;
            }
        });
    }

    private void updateSpans(Editable editable) {
        if (isUpdatingSpans || editable == null) return;
        isUpdatingSpans = true;
        try {
            PageNumberSpan[] oldPageSpans = editable.getSpans(0, editable.length(), PageNumberSpan.class);
            for (PageNumberSpan span : oldPageSpans) editable.removeSpan(span);

            PageColorSpan[] oldColorSpans = editable.getSpans(0, editable.length(), PageColorSpan.class);
            for (PageColorSpan span : oldColorSpans) editable.removeSpan(span);

            PageUnderlineSpan[] oldUnderlineSpans = editable.getSpans(0, editable.length(), PageUnderlineSpan.class);
            for (PageUnderlineSpan span : oldUnderlineSpans) editable.removeSpan(span);

            PageBoldSpan[] oldBoldSpans = editable.getSpans(0, editable.length(), PageBoldSpan.class);
            for (PageBoldSpan span : oldBoldSpans) editable.removeSpan(span);

            Context context = getContext();
            boolean isDark = context != null && ThemeManager.isDarkMode(context);
            int linkColor = isDark ? 0xFF64B5F6 : 0xFF1565C0;

            String text = editable.toString();
            Matcher matcher = PAGE_REF_PATTERN.matcher(text);

            while (matcher.find()) {
                int fullStart = matcher.start();
                int fullEnd = matcher.end();
                int numStart = matcher.start(1);
                int numEnd = matcher.end(1);

                int pageNum = parsePageNumber(matcher.group(1));
                if (pageNum > 0) {
                    editable.setSpan(new PageColorSpan(linkColor), numStart, numEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    editable.setSpan(new PageUnderlineSpan(), numStart, numEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    editable.setSpan(new PageBoldSpan(), numStart, numEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    editable.setSpan(new PageNumberSpan(pageNum), fullStart, fullEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        } finally {
            isUpdatingSpans = false;
        }
    }

    public static int parsePageNumber(String str) {
        if (str == null || str.isEmpty()) return -1;
        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (c >= '0' && c <= '9') {
                sb.append(c);
            } else {
                switch (c) {
                    case '০': sb.append('0'); break;
                    case '১': sb.append('1'); break;
                    case '২': sb.append('2'); break;
                    case '৩': sb.append('3'); break;
                    case '৪': sb.append('4'); break;
                    case '৫': sb.append('5'); break;
                    case '৬': sb.append('6'); break;
                    case '৭': sb.append('7'); break;
                    case '৮': sb.append('8'); break;
                    case '৯': sb.append('9'); break;
                }
            }
        }
        try {
            return Integer.parseInt(sb.toString());
        } catch (Exception e) {
            return -1;
        }
    }
}
