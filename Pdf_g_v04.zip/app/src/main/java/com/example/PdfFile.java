package com.example;

import android.net.Uri;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PdfFile implements Serializable {
    private long id;
    private String name;
    private String path;
    private String uriString;
    private long size;
    private long dateModified;
    private int pageCount = -1;

    public PdfFile(long id, String name, String path, Uri uri, long size, long dateModified) {
        this.id = id;
        this.name = name;
        this.path = path;
        this.uriString = (uri != null) ? uri.toString() : "";
        this.size = size;
        this.dateModified = dateModified;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name != null ? name : "Document.pdf";
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path != null ? path : "";
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Uri getUri() {
        return uriString != null && !uriString.isEmpty() ? Uri.parse(uriString) : null;
    }

    public void setUri(Uri uri) {
        this.uriString = (uri != null) ? uri.toString() : "";
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public long getDateModified() {
        return dateModified;
    }

    public void setDateModified(long dateModified) {
        this.dateModified = dateModified;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public String getFormattedSize() {
        if (size <= 0) return "0 B";
        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        if (digitGroups >= units.length) digitGroups = units.length - 1;
        return String.format(Locale.getDefault(), "%.2f %s", size / Math.pow(1024, digitGroups), units[digitGroups]);
    }

    public String getFormattedDate() {
        try {
            long timeMs = dateModified;
            if (timeMs < 100000000000L) {
                // If timestamp in seconds
                timeMs *= 1000L;
            }
            SimpleDateFormat sdf = new SimpleDateFormat("MMM d", Locale.getDefault());
            return sdf.format(new Date(timeMs));
        } catch (Exception e) {
            return "Recent";
        }
    }

    public String getFormattedFullDate() {
        try {
            long timeMs = dateModified;
            if (timeMs < 100000000000L) {
                timeMs *= 1000L;
            }
            SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault());
            return sdf.format(new Date(timeMs));
        } catch (Exception e) {
            return "Unknown";
        }
    }
}
