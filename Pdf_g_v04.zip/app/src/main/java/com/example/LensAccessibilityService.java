package com.example;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

/**
 * Drives the REAL Google Lens screen for the user:
 *   1. taps "Select text"  -> Lens selects every recognised line
 *   2. taps "Copy text"    -> Lens puts all of it on the clipboard
 * No OCR of our own is involved. The text itself is read afterwards from the clipboard
 * (see {@link ClipboardGrabActivity}).
 *
 * The user must switch this service on once: Settings > Accessibility > PDF Gallery - Lens Auto Copy.
 */
public class LensAccessibilityService extends AccessibilityService {

    private static volatile LensAccessibilityService instance;

    /** The service object if the user switched it on, otherwise null. */
    public static LensAccessibilityService get() {
        return instance;
    }

    private static final String[] LENS_PACKAGES = {
            "com.google.android.googlequicksearchbox",
            "com.google.ar.lens"
    };

    // Matching is "contains", lower-case, on node text AND contentDescription.
    // Order matters: the first label that matches wins. Add more here if your Lens language differs.
    private static final String[] SELECT_TEXT_LABELS = {
            "select text", "টেক্সট নির্বাচন", "টেক্সট সিলেক্ট", "লেখা নির্বাচন", "লেখা সিলেক্ট", "text auswählen",
            "seleccionar texto", "sélectionner le texte"
    };
    private static final String[] COPY_TEXT_LABELS = {
            "copy text", "copy all", "টেক্সট কপি", "লেখা কপি", "সব কপি", "texto kopieren", "copiar texto",
            "copier le texte", "copy", "কপি"
    };
    /** A node whose label contains one of these is NOT the text-copy button. */
    private static final String[] COPY_EXCLUDE = {
            "image", "photo", "link", "url", "ছবি", "লিঙ্ক", "path"
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { /* polled on demand */ }

    @Override
    public void onInterrupt() { }

    // ------------------------------------------------------------------------------------

    /**
     * Blocking - call from a background thread only.
     * Taps "Select text" (if shown) and then "Copy text" on the Google Lens screen.
     *
     * @return true when the "Copy text" button was tapped
     */
    public boolean copyAllLensText(long timeoutMs, BooleanSupplier cancelled) {
        final long deadline = System.currentTimeMillis() + timeoutMs;
        long lastSelectTap = 0;
        int selectTaps = 0;

        while (System.currentTimeMillis() < deadline) {
            if (cancelled != null && cancelled.getAsBoolean()) return false;

            List<AccessibilityNodeInfo> roots = lensRoots();
            try {
                if (!roots.isEmpty()) {
                    // 1) Text already selected -> copy button is on screen: tap it right away
                    AccessibilityNodeInfo copy = find(roots, COPY_TEXT_LABELS, COPY_EXCLUDE);
                    if (copy != null && click(copy)) {
                        sleep(60);
                        return true;
                    }
                    // 2) Otherwise press "Select text". Lens ignores the tap while it is still reading the
                    //    image, so repeat every second (the chip disappears once the text is selected).
                    long now = System.currentTimeMillis();
                    if (selectTaps < 12 && now - lastSelectTap > 1000) {
                        AccessibilityNodeInfo sel = find(roots, SELECT_TEXT_LABELS, null);
                        if (sel != null && click(sel)) {
                            selectTaps++;
                            lastSelectTap = now;
                            sleep(100);
                            continue;
                        }
                    }
                }
            } finally {
                recycleAll(roots);
            }
            sleep(70);
        }
        return false;
    }

    /** Reads the clipboard straight from this service (works on many devices); "" when not allowed. */
    public String readClipboardDirect() {
        try {
            android.content.ClipboardManager cb =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cb == null || !cb.hasPrimaryClip()) return "";
            android.content.ClipData clip = cb.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return "";
            CharSequence cs = clip.getItemAt(0).coerceToText(this);
            return cs == null ? "" : cs.toString();
        } catch (Exception e) {
            return "";
        }
    }

    // ---- helpers -----------------------------------------------------------------------

    private List<AccessibilityNodeInfo> lensRoots() {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows != null) {
                for (AccessibilityWindowInfo w : windows) {
                    AccessibilityNodeInfo r = w.getRoot();
                    if (r == null) continue;
                    if (isLensPackage(r.getPackageName())) out.add(r); else r.recycle();
                }
            }
        } catch (Exception ignored) {}
        if (out.isEmpty()) {
            try {
                AccessibilityNodeInfo r = getRootInActiveWindow();
                if (r != null) {
                    if (isLensPackage(r.getPackageName())) out.add(r); else r.recycle();
                }
            } catch (Exception ignored) {}
        }
        return out;
    }

    private static boolean isLensPackage(CharSequence pkg) {
        if (pkg == null) return false;
        for (String p : LENS_PACKAGES) if (p.contentEquals(pkg)) return true;
        return false;
    }

    /** ONE tree walk; of all matching nodes the one with the highest-priority label (lowest index) wins. */
    private AccessibilityNodeInfo find(List<AccessibilityNodeInfo> roots, String[] labels, String[] exclude) {
        AccessibilityNodeInfo[] best = {null};
        int[] bestIdx = {Integer.MAX_VALUE};
        for (AccessibilityNodeInfo root : roots) {
            walk(root, labels, exclude, best, bestIdx, 0);
            if (bestIdx[0] == 0) break;
        }
        return best[0];
    }

    private void walk(AccessibilityNodeInfo node, String[] labels, String[] exclude,
                      AccessibilityNodeInfo[] best, int[] bestIdx, int depth) {
        if (node == null || depth > 40 || bestIdx[0] == 0) return;
        if (node.isVisibleToUser()) {
            for (int i = 0; i < labels.length && i < bestIdx[0]; i++) {
                if (matches(node, labels[i], exclude)) {
                    best[0] = node;
                    bestIdx[0] = i;
                    break;
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) walk(child, labels, exclude, best, bestIdx, depth + 1);
        }
    }

    private static boolean matches(AccessibilityNodeInfo n, String label, String[] exclude) {
        String t = lower(n.getText());
        String d = lower(n.getContentDescription());
        boolean hit = (!t.isEmpty() && t.contains(label)) || (!d.isEmpty() && d.contains(label));
        if (!hit) return false;
        // Very long text = a paragraph of recognised text that merely contains the word, not a button
        if (t.length() > 40 && d.length() > 40) return false;
        if (exclude != null) {
            for (String x : exclude) {
                if (t.contains(x) || d.contains(x)) return false;
            }
        }
        return true;
    }

    private static String lower(CharSequence cs) {
        return cs == null ? "" : cs.toString().trim().toLowerCase(Locale.ROOT);
    }

    /** ACTION_CLICK on the node (or its first clickable parent); falls back to a real finger tap. */
    private boolean click(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 6 && n != null; i++) {
            if (n.isClickable() && n.isEnabled()) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            }
            n = n.getParent();
        }
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return false;
        return tap(r.centerX(), r.centerY());
    }

    private boolean tap(int x, int y) {
        try {
            Path p = new Path();
            p.moveTo(x, y);
            GestureDescription g = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(p, 0, 60))
                    .build();
            final CountDownLatch done = new CountDownLatch(1);
            final boolean[] ok = {false};
            boolean dispatched = dispatchGesture(g, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { ok[0] = true; done.countDown(); }
                @Override public void onCancelled(GestureDescription d) { done.countDown(); }
            }, null);
            if (!dispatched) return false;
            done.await(2, TimeUnit.SECONDS);
            return ok[0];
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private static void recycleAll(List<AccessibilityNodeInfo> list) {
        for (AccessibilityNodeInfo n : list) {
            try { n.recycle(); } catch (Exception ignored) {}
        }
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
