package com.example;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Opens the existing Unlimited Note editor (PdfNotesDialog) on its own, straight from the
 * Google Lens page bar. It lives in its own task, so closing it (X / Save / Back) simply drops
 * the user back on the Google Lens page they came from. The floating bar is hidden while the
 * note is open and shown again when it closes.
 */
public class LensNoteActivity extends AppCompatActivity {

    private static final String EXTRA_NOTE_ID = "lens_note_id";
    private static final String EXTRA_PDF_NAME = "lens_note_pdf_name";

    public static void launch(Context context, String noteId, String pdfName) {
        Intent i = new Intent(context, LensNoteActivity.class);
        i.putExtra(EXTRA_NOTE_ID, noteId);
        i.putExtra(EXTRA_PDF_NAME, pdfName);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(i);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String noteId = getIntent().getStringExtra(EXTRA_NOTE_ID);
        String pdfName = getIntent().getStringExtra(EXTRA_PDF_NAME);

        // After process death / re-creation there is nothing sensible to restore.
        if (savedInstanceState != null || noteId == null) {
            finish();
            return;
        }

        PdfNotesDialog dialog = PdfNotesDialog.newInstance(noteId, pdfName);
        dialog.setOnDismissCallback(this::finish);
        dialog.show(getSupportFragmentManager(), "PdfNotesDialog");
    }

    @Override
    protected void onDestroy() {
        // Bring the Lens page bar back no matter how the note screen was closed.
        LensNavigatorService.setBarVisible(true);
        super.onDestroy();
    }
}
