package com.example;

import android.Manifest;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.Insets;
import androidx.core.graphics.drawable.IconCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import android.view.ViewGroup;
import android.view.WindowManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements PdfAdapter.OnPdfActionListener, DownloadPdfAdapter.OnDownloadActionListener {

    private static final int REQUEST_STORAGE_PERMISSION = 100;
    private static final int REQUEST_PICK_PDF = 101;
    private static final int REQUEST_PICK_COVER_IMAGE = 102;
    private static final int REQUEST_EXPORT_BACKUP = 103;
    private static final int REQUEST_IMPORT_BACKUP = 104;
    private static final int REQUEST_CHANGE_EXISTING_COVER = 105;

    private RecyclerView recyclerViewPdfs;
    private RecyclerView recyclerViewDownloads;
    private PdfAdapter pdfAdapter;
    private DownloadPdfAdapter downloadPdfAdapter;

    private ProgressBar progressBar;
    private View layoutEmptyState;
    private ImageView ivEmptyIcon;
    private TextView tvEmptyTitle;
    private TextView tvEmptySubtitle;
    private TextView tvSubtitleCount;
    private TextView tvMainTitle;
    private EditText etSearchPdfs;
    private ImageButton btnClearSearch;

    private ExtendedFloatingActionButton fabImport;
    private MaterialButton btnImportUrl;
    private View fabContainer;
    private MaterialButton btnEmptyImport;
    private MaterialButton btnEmptyImportUrl;
    private MaterialButton btnGenerateSamples;
    private MaterialButton btnEmptyCreateSamples;

    // 3-Line Menu & Multi-selection & Folders
    private ImageButton btnMainMenu;
    private View layoutMultiSelectBar;
    private ImageButton btnCancelMultiSelect;
    private TextView tvSelectedCount;
    private MaterialButton btnCreateFolderFromSelected;
    private View layoutActiveFolderBanner;
    private Chip chipActiveFolder;
    private com.google.android.material.chip.ChipGroup chipGroupFolders;
    private View scrollFolderBar;
    private MaterialButton btnQuickCreateFolder;
    private String targetItemIdForCoverChange = null;

    // Bottom Navigation Bar tabs
    private View tabHome;
    private View tabDownload;
    private View tabExport;
    private View tabImport;
    private ImageView ivTabHomeIcon;
    private TextView tvTabHomeText;
    private ImageView ivTabDownloadIcon;
    private TextView tvTabDownloadText;

    private boolean isDownloadsTabActive = false;

    private FolderManager folderManager;
    private FavoritesManager favoritesManager;
    private UrlPdfManager urlPdfManager;
    private String currentSelectedFolder = FolderManager.FOLDER_ALL;
    private GestureDetector swipeGestureDetector;

    private final List<PdfFile> pdfList = new ArrayList<>();

    // Temporary storage for cover selection dialog
    private Uri tempSelectedCoverUri = null;
    private ImageView tempCoverPreviewRef = null;
    private TextView tempCoverStatusRef = null;

    // Requirement 3: Variable to store the shared URL / text received from other apps
    private String sharedUrl = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        ThemeManager.applySavedTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupRecyclerViews();
        setupListeners();
        initSwipeGesture();
        checkPermissionsAndLoad();

        // Requirement 3: Extract shared text/URL from external apps (Facebook Reels, Chrome, YouTube, etc.)
        handleIncomingShareIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // Handle when app is already running and receives a new share intent
        handleIncomingShareIntent(intent);
    }

    /**
     * Requirement 3: Clean Java implementation to extract shared text/URL using getIntent().
     * Includes null checks and condition handling so the app runs smoothly when opened normally.
     */
    private void handleIncomingShareIntent(Intent intent) {
        if (intent == null) return;

        String action = intent.getAction();
        String type = intent.getType();

        // Check if this intent is an ACTION_SEND with text/plain mime type
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type) || type.startsWith("text/")) {
                String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (sharedText != null && !sharedText.trim().isEmpty()) {
                    // Store received URL string into variable named sharedUrl
                    this.sharedUrl = sharedText.trim();

                    // Practical Integration: process the received sharedUrl
                    processSharedUrl(this.sharedUrl);
                }
            }
        }
    }

    /**
     * Practical Integration Example:
     * 1. Displays the received sharedUrl (in UI Toast and status)
     * 2. Opens the Import URL dialog prefilled with the shared link
     * 3. Passes sharedUrl as a parameter to an AI API/Gemini API method
     */
    private void processSharedUrl(String receivedUrl) {
        if (receivedUrl == null || receivedUrl.trim().isEmpty()) return;

        Toast.makeText(this, "Shared URL received: " + receivedUrl, Toast.LENGTH_LONG).show();

        // Import URL lives only in the Download tab
        switchToDownloadTab();

        // Practical Action 1: Automatically open Import URL dialog with this link
        showImportUrlDialogWithPrefilledUrl(receivedUrl);

        // Practical Action 2: Pass receivedUrl as parameter to an AI endpoint method
        sendUrlToAiEndpoint(receivedUrl);
    }

    /**
     * Practical Integration Example: Passing the received sharedUrl to an AI / Gemini API endpoint.
     */
    private void sendUrlToAiEndpoint(String url) {
        // Example method demonstrating sending shared URL to an AI API or Gemini endpoint:
        // GeminiApiHelper.analyzeDocumentUrl(url, new AiCallback() { ... });
        android.util.Log.d("MainActivity", "Sending sharedUrl to AI API endpoint: " + url);
    }

    private void initViews() {
        recyclerViewPdfs = findViewById(R.id.recyclerViewPdfs);
        recyclerViewDownloads = findViewById(R.id.recyclerViewDownloads);
        progressBar = findViewById(R.id.progressBar);
        layoutEmptyState = findViewById(R.id.layoutEmptyState);
        ivEmptyIcon = findViewById(R.id.ivEmptyIcon);
        tvEmptyTitle = findViewById(R.id.tvEmptyTitle);
        tvEmptySubtitle = findViewById(R.id.tvEmptySubtitle);
        tvSubtitleCount = findViewById(R.id.tvSubtitleCount);
        tvMainTitle = findViewById(R.id.tvMainTitle);
        etSearchPdfs = findViewById(R.id.etSearchPdfs);
        btnClearSearch = findViewById(R.id.btnClearSearch);

        fabContainer = findViewById(R.id.fabContainer);
        fabImport = findViewById(R.id.fabImport);
        btnImportUrl = findViewById(R.id.btnImportUrl);
        btnGenerateSamples = findViewById(R.id.btnGenerateSamples);
        btnEmptyImport = findViewById(R.id.btnEmptyImport);
        btnEmptyImportUrl = findViewById(R.id.btnEmptyImportUrl);
        btnEmptyCreateSamples = findViewById(R.id.btnEmptyCreateSamples);

        // 3-Line Menu & Multi-selection views
        btnMainMenu = findViewById(R.id.btnMainMenu);
        layoutMultiSelectBar = findViewById(R.id.layoutMultiSelectBar);
        btnCancelMultiSelect = findViewById(R.id.btnCancelMultiSelect);
        tvSelectedCount = findViewById(R.id.tvSelectedCount);
        btnCreateFolderFromSelected = findViewById(R.id.btnCreateFolderFromSelected);
        layoutActiveFolderBanner = findViewById(R.id.layoutActiveFolderBanner);
        chipActiveFolder = findViewById(R.id.chipActiveFolder);
        chipGroupFolders = findViewById(R.id.chipGroupFolders);
        scrollFolderBar = findViewById(R.id.scrollFolderBar);
        btnQuickCreateFolder = findViewById(R.id.btnQuickCreateFolder);
        if (btnQuickCreateFolder != null) {
            btnQuickCreateFolder.setOnClickListener(v -> showCreateFolderDialog(null));
        }

        // Bottom Navigation Bar
        View bottomNavContainer = findViewById(R.id.bottomNavContainer);
        tabHome = findViewById(R.id.tabHome);
        tabDownload = findViewById(R.id.tabDownload);
        tabExport = findViewById(R.id.tabExport);
        tabImport = findViewById(R.id.tabImport);
        ivTabHomeIcon = findViewById(R.id.ivTabHomeIcon);
        tvTabHomeText = findViewById(R.id.tvTabHomeText);
        ivTabDownloadIcon = findViewById(R.id.ivTabDownloadIcon);
        tvTabDownloadText = findViewById(R.id.tvTabDownloadText);

        // Requirement 3: Ensure bottom navigation bar and floating action buttons are comfortably
        // placed above the Android system navigation bar (3-button navigation / gesture bar) so every button is easy to click
        View targetBottomNav = bottomNavContainer != null ? bottomNavContainer : findViewById(R.id.bottomNavigationBar);
        if (targetBottomNav != null) {
            ViewCompat.setOnApplyWindowInsetsListener(targetBottomNav, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(0, 0, 0, systemBars.bottom);

                if (fabContainer != null) {
                    ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) fabContainer.getLayoutParams();
                    if (lp != null) {
                        int baseMargin = (int) (64 * getResources().getDisplayMetrics().density);
                        lp.bottomMargin = baseMargin + systemBars.bottom;
                        fabContainer.setLayoutParams(lp);
                    }
                }
                return insets;
            });
        }

        folderManager = new FolderManager(this);
        favoritesManager = new FavoritesManager(this);
        urlPdfManager = new UrlPdfManager(this);

        // Ensure background floating bubble is turned off
        if (FloatingBubbleService.isServiceRunning) {
            try {
                Intent serviceIntent = new Intent(this, FloatingBubbleService.class);
                serviceIntent.setAction(FloatingBubbleService.ACTION_STOP);
                stopService(serviceIntent);
                FloatingBubbleService.isServiceRunning = false;
            } catch (Exception ignored) {}
        }
    }

    private void setupRecyclerViews() {
        pdfAdapter = new PdfAdapter(this, this);
        recyclerViewPdfs.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewPdfs.setAdapter(pdfAdapter);

        downloadPdfAdapter = new DownloadPdfAdapter(this, this);
        recyclerViewDownloads.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewDownloads.setAdapter(downloadPdfAdapter);
    }

    private void setupListeners() {
        fabImport.setOnClickListener(v -> openDocumentPicker());
        btnEmptyImport.setOnClickListener(v -> openDocumentPicker());

        btnImportUrl.setOnClickListener(v -> showImportUrlDialog());
        btnEmptyImportUrl.setOnClickListener(v -> showImportUrlDialog());

        btnGenerateSamples.setOnClickListener(v -> createSamplesAndReload());
        btnEmptyCreateSamples.setOnClickListener(v -> createSamplesAndReload());

        etSearchPdfs.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString();
                btnClearSearch.setVisibility(query.isEmpty() ? View.GONE : View.VISIBLE);
                if (!isDownloadsTabActive) {
                    pdfAdapter.filter(query);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnClearSearch.setOnClickListener(v -> etSearchPdfs.setText(""));

        // 3-Line Menu
        btnMainMenu.setOnClickListener(v -> showMainMenuBottomSheet());

        // Cancel Multi-Selection
        btnCancelMultiSelect.setOnClickListener(v -> pdfAdapter.clearSelectionMode());

        // Create Folder from Selected PDFs
        btnCreateFolderFromSelected.setOnClickListener(v -> showCreateFolderDialogForSelected());

        // Clear Folder Filter
        chipActiveFolder.setOnCloseIconClickListener(v -> clearFolderFilter());

        // Bottom Navigation Listeners
        tabHome.setOnClickListener(v -> switchToHomeTab());
        tabDownload.setOnClickListener(v -> switchToDownloadTab());
        tabExport.setOnClickListener(v -> launchExportBackup());
        tabImport.setOnClickListener(v -> launchImportBackup());
    }

    private void switchToHomeTab() {
        isDownloadsTabActive = false;
        recyclerViewDownloads.setVisibility(View.GONE);
        recyclerViewPdfs.setVisibility(pdfList.isEmpty() ? View.GONE : View.VISIBLE);
        // Import PDF / Import URL buttons exist ONLY in the Download tab
        fabContainer.setVisibility(View.GONE);
        btnEmptyImport.setVisibility(View.GONE);
        btnEmptyImportUrl.setVisibility(View.GONE);
        layoutEmptyState.setVisibility(pdfList.isEmpty() ? View.VISIBLE : View.GONE);
        if (pdfList.isEmpty()) {
            tvEmptyTitle.setText(R.string.no_pdfs_found);
            tvEmptySubtitle.setText(R.string.no_pdfs_subtitle);
        }
        if (scrollFolderBar != null) scrollFolderBar.setVisibility(View.VISIBLE);
        tvMainTitle.setText(R.string.app_name);
        tvSubtitleCount.setText(String.format("%d documents found", pdfList.size()));

        ivTabHomeIcon.setColorFilter(ContextCompat.getColor(this, R.color.primary));
        tvTabHomeText.setTextColor(ContextCompat.getColor(this, R.color.primary));
        ivTabDownloadIcon.setColorFilter(ContextCompat.getColor(this, R.color.text_secondary));
        tvTabDownloadText.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
    }

    private void switchToDownloadTab() {
        isDownloadsTabActive = true;
        recyclerViewPdfs.setVisibility(View.GONE);
        recyclerViewDownloads.setVisibility(View.VISIBLE);
        // Import PDF / Import URL buttons exist ONLY in the Download tab
        fabContainer.setVisibility(View.VISIBLE);
        btnEmptyImport.setVisibility(View.VISIBLE);
        btnEmptyImportUrl.setVisibility(View.VISIBLE);
        if (scrollFolderBar != null) scrollFolderBar.setVisibility(View.GONE);
        if (layoutActiveFolderBanner != null) layoutActiveFolderBanner.setVisibility(View.GONE);
        tvMainTitle.setText(R.string.app_name);

        ivTabHomeIcon.setColorFilter(ContextCompat.getColor(this, R.color.text_secondary));
        tvTabHomeText.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        ivTabDownloadIcon.setColorFilter(ContextCompat.getColor(this, R.color.primary));
        tvTabDownloadText.setTextColor(ContextCompat.getColor(this, R.color.primary));

        loadDownloadsList();
    }

    private void loadDownloadsList() {
        List<UrlPdfItem> items = urlPdfManager.getAllItems();
        downloadPdfAdapter.setItems(items);
        tvSubtitleCount.setText(String.format("%d URL/Downloaded items", items.size()));

        if (items.isEmpty()) {
            layoutEmptyState.setVisibility(View.VISIBLE);
            recyclerViewDownloads.setVisibility(View.GONE);
            tvEmptyTitle.setText("No Downloaded PDFs");
            tvEmptySubtitle.setText("Click 'Import URL' to add a Google Drive PDF link and download it for offline reading.");
        } else {
            layoutEmptyState.setVisibility(View.GONE);
            recyclerViewDownloads.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Requirement 3: Import URL Feature
     * Opens solid dialog to input Google Drive link, PDF title (auto-extracted), and custom cover image.
     */
    private void showImportUrlDialog() {
        showImportUrlDialogWithPrefilledUrl(null);
    }

    private void showImportUrlDialogWithPrefilledUrl(@Nullable String prefilledUrl) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_import_url, null);
        dialog.setContentView(view);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int targetWidth = (int) Math.min(screenWidth * 0.94f, 540 * getResources().getDisplayMetrics().density);
            dialog.getWindow().setLayout(targetWidth, ViewGroup.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().setDimAmount(0.65f);
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }

        TextInputEditText etDriveUrl = view.findViewById(R.id.etDriveUrl);
        TextInputEditText etPdfTitle = view.findViewById(R.id.etPdfTitle);
        TextInputLayout tilTitle = view.findViewById(R.id.tilTitle);
        ProgressBar pbFetchingTitle = view.findViewById(R.id.pbFetchingTitle);
        MaterialButton btnSelectCover = view.findViewById(R.id.btnSelectCover);
        ImageView ivCoverPreview = view.findViewById(R.id.ivCoverPreview);
        TextView tvCoverStatus = view.findViewById(R.id.tvCoverStatus);
        MaterialButton btnCancel = view.findViewById(R.id.btnCancelImportUrl);
        MaterialButton btnConfirm = view.findViewById(R.id.btnConfirmImportUrl);

        tempSelectedCoverUri = null;
        tempCoverPreviewRef = ivCoverPreview;
        tempCoverStatusRef = tvCoverStatus;

        // Auto-paste latest copied text or link from clipboard into Google Drive Link (URL) box
        if (prefilledUrl != null && !prefilledUrl.trim().isEmpty()) {
            etDriveUrl.setText(prefilledUrl.trim());
            etDriveUrl.setSelection(prefilledUrl.trim().length());
        } else {
            try {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip()) {
                    ClipData clipData = clipboard.getPrimaryClip();
                    if (clipData != null && clipData.getItemCount() > 0) {
                        CharSequence text = clipData.getItemAt(0).getText();
                        if (text != null && text.length() > 0) {
                            String copied = text.toString().trim();
                            etDriveUrl.setText(copied);
                            etDriveUrl.setSelection(copied.length());
                            Toast.makeText(this, "ক্লিপবোর্ডের লিংক স্বয়ংক্রিয়ভাবে পেস্ট হয়েছে", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            } catch (Exception ignored) {}
        }

        // Auto-extract title when user pastes or types Google Drive link
        final Runnable[] titleTask = new Runnable[1];
        final android.os.Handler searchHandler = new android.os.Handler(android.os.Looper.getMainLooper());

        etDriveUrl.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (titleTask[0] != null) searchHandler.removeCallbacks(titleTask[0]);

                String urlText = s != null ? s.toString().trim() : "";
                if (urlText.length() > 10 && (urlText.contains("drive.google.com") || urlText.contains("/d/") || urlText.contains("id="))) {
                    titleTask[0] = () -> {
                        if (pbFetchingTitle != null) pbFetchingTitle.setVisibility(View.VISIBLE);
                        if (tilTitle != null) tilTitle.setHelperText("গুগল ড্রাইভ থেকে ফাইলের নাম আনা হচ্ছে...");

                        UrlPdfManager.fetchDriveTitleAsync(urlText, new UrlPdfManager.DriveTitleCallback() {
                            @Override
                            public void onTitleFetched(String title) {
                                if (pbFetchingTitle != null) pbFetchingTitle.setVisibility(View.GONE);
                                if (isFinishing()) return;

                                String current = etPdfTitle.getText() != null ? etPdfTitle.getText().toString().trim() : "";
                                if (current.isEmpty() || current.startsWith("Drive_Document_")) {
                                    etPdfTitle.setText(title);
                                }
                                if (tilTitle != null) {
                                    tilTitle.setHelperText("✓ গুগল ড্রাইভ থেকে স্বয়ংক্রিয়ভাবে নাম সেট হয়েছে");
                                }
                            }

                            @Override
                            public void onError(String error) {
                                if (pbFetchingTitle != null) pbFetchingTitle.setVisibility(View.GONE);
                                if (tilTitle != null) {
                                    tilTitle.setHelperText("গুগল ড্রাইভ লিংক দিলে ফাইলের নাম স্বয়ংক্রিয়ভাবে যোগ হবে");
                                }
                            }
                        });
                    };
                    searchHandler.postDelayed(titleTask[0], 400);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnSelectCover.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(Intent.createChooser(intent, "Select Cover Image"), REQUEST_PICK_COVER_IMAGE);
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnConfirm.setOnClickListener(v -> {
            String rawUrl = etDriveUrl.getText() != null ? etDriveUrl.getText().toString().trim() : "";
            if (rawUrl.isEmpty()) {
                Toast.makeText(this, "অনুগ্রহ করে গুগল ড্রাইভের লিংক দিন", Toast.LENGTH_SHORT).show();
                return;
            }

            String customTitle = etPdfTitle.getText() != null ? etPdfTitle.getText().toString().trim() : "";
            if (customTitle.isEmpty()) {
                // Try quick extraction if not yet entered
                btnConfirm.setEnabled(false);
                btnConfirm.setText("যাচাই করা হচ্ছে...");
                if (pbFetchingTitle != null) pbFetchingTitle.setVisibility(View.VISIBLE);

                Executors.newSingleThreadExecutor().execute(() -> {
                    String fetched = UrlPdfManager.fetchDriveTitleSync(rawUrl, 4);
                    runOnUiThread(() -> {
                        btnConfirm.setEnabled(true);
                        btnConfirm.setText("Import PDF");
                        if (pbFetchingTitle != null) pbFetchingTitle.setVisibility(View.GONE);

                        String finalTitle = fetched;
                        if (finalTitle == null || finalTitle.trim().isEmpty()) {
                            finalTitle = "Drive_Document_" + (urlPdfManager.getAllItems().size() + 1) + ".pdf";
                        }
                        if (!finalTitle.toLowerCase().endsWith(".pdf")) {
                            finalTitle += ".pdf";
                        }
                        finalizeImport(dialog, rawUrl, finalTitle);
                    });
                });
                return;
            }

            if (!customTitle.toLowerCase().endsWith(".pdf")) {
                customTitle += ".pdf";
            }
            finalizeImport(dialog, rawUrl, customTitle);
        });

        dialog.show();
    }

    private void finalizeImport(Dialog dialog, String rawUrl, String customTitle) {
        // Save cover image to private storage if chosen
        String coverPath = null;
        if (tempSelectedCoverUri != null) {
            coverPath = urlPdfManager.saveCoverImageToInternalStorage(tempSelectedCoverUri);
        }

        String downloadUrl = UrlPdfManager.extractDirectDownloadUrl(rawUrl);
        String id = "url_" + System.currentTimeMillis();

        UrlPdfItem newItem = new UrlPdfItem(id, customTitle, rawUrl, downloadUrl, coverPath);
        urlPdfManager.saveItem(newItem);

        if (coverPath == null) {
            String driveId = UrlPdfManager.extractGoogleDriveFileId(rawUrl);
            if (driveId != null) {
                Executors.newSingleThreadExecutor().execute(() -> {
                    String thumb = PdfUtils.downloadDriveThumbnailIfAvailable(MainActivity.this, driveId, id);
                    if (thumb != null) {
                        urlPdfManager.updateCoverImagePath(id, thumb);
                        runOnUiThread(() -> {
                            if (isDownloadsTabActive) loadDownloadsList();
                        });
                    }
                });
            }
        }

        dialog.dismiss();
        Toast.makeText(this, "PDF যোগ হয়েছে! পড়তে 'Download' বাটনে চাপ দিন", Toast.LENGTH_LONG).show();

        // Switch to download tab so user sees it right away
        switchToDownloadTab();
    }

    /**
     * DownloadPdfAdapter Action Callbacks
     */
    @Override
    public void onReadClick(UrlPdfItem item, DownloadPdfAdapter.ViewHolder holder) {
        if (item.isDownloaded() && item.getLocalFilePath() != null) {
            File file = new File(item.getLocalFilePath());
            if (file.exists() && UrlPdfManager.isValidPdfFile(file)) {
                // Open in full PDF Viewer (supports reading, notes, google lens, page linking)
                Uri uri = FileProvider.getUriForFile(this, PdfUtils.FILE_PROVIDER_AUTHORITY, file);
                Intent intent = new Intent(this, PdfViewerActivity.class);
                intent.putExtra(PdfViewerActivity.EXTRA_PDF_PATH, file.getAbsolutePath());
                intent.putExtra(PdfViewerActivity.EXTRA_PDF_NAME, item.getTitle());
                intent.putExtra(PdfViewerActivity.EXTRA_PDF_URI, uri.toString());
                startActivity(intent);
                return;
            } else {
                // Corrupted file cleanup
                if (file.exists()) file.delete();
                item.setDownloaded(false);
                item.setLocalFilePath(null);
                urlPdfManager.saveItem(item);
                holder.tvUrlPdfStatus.setText("ফাইলটি ত্রুটিপূর্ণ ছিল। পুনরায় ডাউনলোড বাটনে চাপুন।");
                holder.btnActionRead.setText("Download");
                holder.btnActionRead.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.primary));
                Toast.makeText(this, "ফাইলটি সঠিক PDF ছিল না। পুনরায় ডাউনলোড করা হচ্ছে...", Toast.LENGTH_SHORT).show();
            }
        }

        // Start download flow
        holder.layoutDownloadProgress.setVisibility(View.VISIBLE);
        holder.tvUrlPdfStatus.setText("Google Drive থেকে ডাউনলোড শুরু হচ্ছে...");
        holder.btnActionRead.setEnabled(false);
        holder.btnActionRead.setText("Wait");

        PdfDownloadHelper.getInstance(this).downloadPdf(item, new PdfDownloadHelper.DownloadCallback() {
            @Override
            public void onProgress(int percent, long downloadedBytes, long totalBytes) {
                // Progress is already updated dynamically by DownloadPdfAdapter as a DownloadStateListener!
            }

            @Override
            public void onSuccess(File downloadedFile) {
                holder.layoutDownloadProgress.setVisibility(View.GONE);
                holder.tvUrlPdfStatus.setText("Downloaded • অফলাইনে পড়ার জন্য প্রস্তুত");
                holder.btnActionRead.setEnabled(true);
                holder.btnActionRead.setText("Read");
                holder.btnActionRead.setBackgroundTintList(ContextCompat.getColorStateList(MainActivity.this, R.color.emerald_green));
                Toast.makeText(MainActivity.this, "ডাউনলোড সফল: " + item.getTitle(), Toast.LENGTH_SHORT).show();

                // Reload main pdf files so it also appears in Home / All PDFs list!
                loadPdfFiles();
                loadDownloadsList();
            }

            @Override
            public void onError(String errorMessage) {
                holder.tvUrlPdfStatus.setText("ব্যর্থ: " + errorMessage);
                holder.btnActionRead.setEnabled(true);
                holder.btnActionRead.setText("Retry");
                holder.btnActionRead.setBackgroundTintList(ContextCompat.getColorStateList(MainActivity.this, R.color.primary));
                Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onDeleteClick(UrlPdfItem item) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Delete PDF")
                .setMessage("Are you sure you want to delete '" + item.getTitle() + "'?")
                .setPositiveButton("Delete", (d, w) -> {
                    PdfDownloadHelper.getInstance(this).deletePartFile(item.getId());
                    urlPdfManager.deleteItem(item.getId());
                    loadDownloadsList();
                    loadPdfFiles();
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onChangeThumbnailClick(UrlPdfItem item) {
        targetItemIdForCoverChange = item.getId();
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "থাম্বনেইল ইমেজ নির্বাচন করুন"), REQUEST_CHANGE_EXISTING_COVER);
    }

    /**
     * Requirement 5: JSON Export and Import
     */
    private void launchExportBackup() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "pdf_gallery_backup_" + System.currentTimeMillis() + ".json");
        startActivityForResult(intent, REQUEST_EXPORT_BACKUP);
    }

    private void launchImportBackup() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_IMPORT_BACKUP);
    }

    private void openDocumentPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_PICK_PDF);
    }

    private void createSamplesAndReload() {
        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            List<PdfFile> samples = PdfUtils.createSamplePdfFiles(this);
            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(this, "Generated " + samples.size() + " sample PDFs", Toast.LENGTH_SHORT).show();
                loadPdfFiles();
            });
        }).start();
    }

    private void checkPermissionsAndLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            loadPdfFiles();
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_STORAGE_PERMISSION
                );
            } else {
                loadPdfFiles();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_STORAGE_PERMISSION) {
            loadPdfFiles();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        Uri uri = data.getData();
        if (uri == null) return;

        if (requestCode == REQUEST_PICK_PDF) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            importPdfFromUri(uri);
        } else if (requestCode == REQUEST_PICK_COVER_IMAGE) {
            tempSelectedCoverUri = uri;
            if (tempCoverPreviewRef != null) {
                try {
                    InputStream in = getContentResolver().openInputStream(uri);
                    Bitmap bmp = BitmapFactory.decodeStream(in);
                    if (in != null) in.close();
                    if (bmp != null) {
                        tempCoverPreviewRef.setImageBitmap(bmp);
                    }
                } catch (Exception ignored) {}
            }
            if (tempCoverStatusRef != null) {
                tempCoverStatusRef.setText("Custom cover image chosen!");
            }
        } else if (requestCode == REQUEST_CHANGE_EXISTING_COVER) {
            if (targetItemIdForCoverChange != null) {
                String savedPath = urlPdfManager.saveCoverImageToInternalStorage(uri);
                if (savedPath != null) {
                    urlPdfManager.updateCoverImagePath(targetItemIdForCoverChange, savedPath);
                    loadDownloadsList();
                    Toast.makeText(this, "কাস্টম থাম্বনেইল সফলভাবে পরিবর্তন করা হয়েছে!", Toast.LENGTH_SHORT).show();
                }
                targetItemIdForCoverChange = null;
            }
        } else if (requestCode == REQUEST_EXPORT_BACKUP) {
            boolean success = BackupManager.exportBackupToUri(this, uri);
            if (success) {
                Toast.makeText(this, "Backup successfully exported to JSON!", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Failed to export backup", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_IMPORT_BACKUP) {
            boolean success = BackupManager.importBackupFromUri(this, uri);
            if (success) {
                Toast.makeText(this, "Backup restored successfully from JSON!", Toast.LENGTH_LONG).show();
                loadPdfFiles();
                if (isDownloadsTabActive) {
                    loadDownloadsList();
                }
            } else {
                Toast.makeText(this, "Failed to restore backup", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void importPdfFromUri(Uri uri) {
        String fileName = "Imported_Document.pdf";
        long fileSize = 0;
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(uri, null, null, null, null);
        if (cursor != null) {
            int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) fileName = cursor.getString(nameIndex);
                if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex);
            }
            cursor.close();
        }

        File destDir = getExternalFilesDir(null);
        if (destDir == null) destDir = getFilesDir();
        File destFile = new File(destDir, fileName);

        try (InputStream is = resolver.openInputStream(uri);
             FileOutputStream fos = new FileOutputStream(destFile)) {
            if (is != null) {
                byte[] buffer = new byte[8192];
                int len;
                while ((len = is.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
            }
            Toast.makeText(this, "Imported " + fileName, Toast.LENGTH_SHORT).show();
            loadPdfFiles();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to import PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void loadPdfFiles() {
        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            List<PdfFile> files = new ArrayList<>();

            // 1. Query MediaStore
            Uri collection;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
            } else {
                collection = MediaStore.Files.getContentUri("external");
            }

            String selection = MediaStore.Files.FileColumns.MIME_TYPE + "=?";
            String[] selectionArgs = new String[]{"application/pdf"};
            String sortOrder = MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC";

            try (Cursor cursor = getContentResolver().query(collection, projection, selection, selectionArgs, sortOrder)) {
                if (cursor != null) {
                    int idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
                    int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
                    int pathCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
                    int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE);
                    int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED);

                    while (cursor.moveToNext()) {
                        long id = cursor.getLong(idCol);
                        String name = cursor.getString(nameCol);
                        String path = cursor.getString(pathCol);
                        long size = cursor.getLong(sizeCol);
                        long date = cursor.getLong(dateCol);

                        String cleanName = PdfUtils.cleanPdfName(name);
                        Uri contentUri = Uri.withAppendedPath(collection, String.valueOf(id));
                        files.add(new PdfFile(id, cleanName, path, contentUri, size, date));
                    }
                }
            } catch (Exception ignored) {}

            // 2. Query App External Files Directory
            File externalDocs = getExternalFilesDir(null);
            if (externalDocs != null && externalDocs.exists()) {
                File[] list = externalDocs.listFiles();
                if (list != null) {
                    for (File f : list) {
                        if (f.getName().toLowerCase().endsWith(".pdf")) {
                            boolean exists = false;
                            for (PdfFile existing : files) {
                                if (existing.getPath() != null && existing.getPath().equals(f.getAbsolutePath())) {
                                    exists = true;
                                    break;
                                }
                            }
                            if (!exists) {
                                Uri uri = FileProvider.getUriForFile(this, PdfUtils.FILE_PROVIDER_AUTHORITY, f);
                                String clean = PdfUtils.cleanPdfName(f.getName());
                                files.add(new PdfFile(f.hashCode(), clean, f.getAbsolutePath(), uri, f.length(), f.lastModified()));
                            }
                        }
                    }
                }
            }

            // 3. Query Downloaded PDFs Directory (from URL import)
            File downloadsDir = urlPdfManager.getDownloadsDirectory();
            if (downloadsDir != null && downloadsDir.exists()) {
                File[] list = downloadsDir.listFiles();
                if (list != null) {
                    for (File f : list) {
                        if (f.getName().toLowerCase().endsWith(".pdf")) {
                            boolean exists = false;
                            for (PdfFile existing : files) {
                                if (existing.getPath() != null && existing.getPath().equals(f.getAbsolutePath())) {
                                    exists = true;
                                    break;
                                }
                            }
                            if (!exists) {
                                Uri uri = FileProvider.getUriForFile(this, PdfUtils.FILE_PROVIDER_AUTHORITY, f);
                                String clean = PdfUtils.cleanPdfName(f.getName());
                                files.add(new PdfFile(f.hashCode(), clean, f.getAbsolutePath(), uri, f.length(), f.lastModified()));
                            }
                        }
                    }
                }
            }

            // 4. If still empty, auto-generate realistic sample PDFs!
            if (files.isEmpty()) {
                files = PdfUtils.createSamplePdfFiles(this);
            }

            // Sort by modified date descending
            Collections.sort(files, (a, b) -> Long.compare(b.getDateModified(), a.getDateModified()));

            final List<PdfFile> finalList = files;
            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                pdfList.clear();
                pdfList.addAll(finalList);
                pdfAdapter.setPdfList(pdfList);
                refreshFolderChips();

                if (!isDownloadsTabActive) {
                    if (pdfList.isEmpty()) {
                        layoutEmptyState.setVisibility(View.VISIBLE);
                        recyclerViewPdfs.setVisibility(View.GONE);
                        tvEmptyTitle.setText(R.string.no_pdfs_found);
                        tvEmptySubtitle.setText(R.string.no_pdfs_subtitle);
                        tvSubtitleCount.setText("No documents");
                    } else {
                        layoutEmptyState.setVisibility(View.GONE);
                        recyclerViewPdfs.setVisibility(View.VISIBLE);
                        filterByFolder(currentSelectedFolder);
                    }
                }
            });
        }).start();
    }

    private static final String[] projection = new String[]{
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
    };

    @Override
    public void onPdfClick(PdfFile pdfFile) {
        Intent intent = new Intent(this, PdfViewerActivity.class);
        intent.putExtra(PdfViewerActivity.EXTRA_PDF_PATH, pdfFile.getPath());
        intent.putExtra(PdfViewerActivity.EXTRA_PDF_NAME, pdfFile.getName());
        if (pdfFile.getUri() != null) {
            intent.putExtra(PdfViewerActivity.EXTRA_PDF_URI, pdfFile.getUri().toString());
        }
        startActivity(intent);
    }

    @Override
    public void onMenuClick(PdfFile pdfFile, View anchorView) {
        showContextualBottomSheet(pdfFile);
    }

    @Override
    public void onSelectionChanged(int selectedCount) {
        if (selectedCount > 0) {
            layoutMultiSelectBar.setVisibility(View.VISIBLE);
            tvSelectedCount.setText(String.format("%dটি ফাইল নির্বাচিত", selectedCount));
        } else {
            layoutMultiSelectBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDeleteClick(PdfFile pdfFile) {
        showDeleteConfirmDialog(pdfFile);
    }

    @Override
    public void onFavoriteToggle(PdfFile pdfFile, boolean isFavorite) {
        String msg = isFavorite ? "ফেবারিট হিসেবে যোগ করা হয়েছে" : "ফেবারিট থেকে বাদ দেওয়া হয়েছে";
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        if (FolderManager.FOLDER_FAVORITES.equalsIgnoreCase(currentSelectedFolder)) {
            filterByFolder(FolderManager.FOLDER_FAVORITES);
        }
    }

    private void showCreateFolderDialogForSelected() {
        List<PdfFile> selected = pdfAdapter.getSelectedFiles();
        if (selected.isEmpty()) {
            Toast.makeText(this, "কোনো ফাইল নির্বাচিত নেই", Toast.LENGTH_SHORT).show();
            return;
        }

        EditText input = new EditText(this);
        input.setHint("ফোল্ডারের নাম লিখুন (যেমন: জীববিজ্ঞান নোট)");
        input.setPadding(48, 32, 48, 32);

        new MaterialAlertDialogBuilder(this)
                .setTitle("নতুন Folder তৈরি করুন")
                .setMessage("নির্বাচিত " + selected.size() + "টি ফাইলের জন্য ফোল্ডারের নাম দিন:")
                .setView(input)
                .setPositiveButton("তৈরি করুন", (dialog, which) -> {
                    String folderName = input.getText().toString().trim();
                    if (folderName.isEmpty()) {
                        Toast.makeText(this, "ফোল্ডারের নাম খালি রাখা যাবে না", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    folderManager.createFolder(folderName);
                    for (PdfFile f : selected) {
                        String id = f.getPath() != null ? f.getPath() : f.getName();
                        folderManager.assignPdfToFolder(id, folderName);
                    }
                    pdfAdapter.clearSelectionMode();
                    Toast.makeText(this, "ফোল্ডার '" + folderName + "' তৈরি হয়েছে", Toast.LENGTH_SHORT).show();
                    filterByFolder(folderName);
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    /**
     * Requirement 2 & 4: 3-line menu (Navigation / Menu Bottom Sheet)
     * - Dark mode & White mode switch
     * - Favorites folder (User Request 2)
     * - Folders matching screenshots (Screenshots, Download, custom folders)
     */
    private void showMainMenuBottomSheet() {
        BottomSheetDialog menuSheet = new BottomSheetDialog(this, R.style.RoundedBottomSheetDialog);
        View sheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_main_menu, null);

        MaterialSwitch switchDarkMode = sheetView.findViewById(R.id.switchDarkMode);
        boolean isDark = ThemeManager.isDarkMode(this);
        switchDarkMode.setChecked(isDark);
        switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            ThemeManager.setDarkMode(this, isChecked);
            menuSheet.dismiss();
        });

        ImageButton btnMenuSettings = sheetView.findViewById(R.id.btnMenuSettings);
        btnMenuSettings.setOnClickListener(v -> {
            menuSheet.dismiss();
            startActivity(new Intent(MainActivity.this, PermissionsActivity.class));
        });

        LinearLayout layoutFolderList = sheetView.findViewById(R.id.layoutFolderList);
        MaterialButton btnMenuCreateFolder = sheetView.findViewById(R.id.btnMenuCreateFolder);

        final Runnable[] populateFoldersRef = new Runnable[1];
        populateFoldersRef[0] = () -> {
            layoutFolderList.removeAllViews();

            // 1. All Files
            addFolderRowToMenu(menuSheet, layoutFolderList, populateFoldersRef[0], FolderManager.FOLDER_ALL, "সব ফাইল (All PDFs)", pdfList.size(), false);

            // 2. Favorites Folder (User request 2: ফেবারিটগুলো ৩লাইন icone এ ফেবারিট ফোল্ডারে থাকবে)
            int favCount = folderManager.filterByFolder(pdfList, FolderManager.FOLDER_FAVORITES).size();
            addFolderRowToMenu(menuSheet, layoutFolderList, populateFoldersRef[0], FolderManager.FOLDER_FAVORITES, "★ ফেভারিট (Favorites)", favCount, false);

            // 3. Default & Custom Folders (Screenshots, Download, etc.)
            List<String> folders = folderManager.getAllFolders();
            for (String fName : folders) {
                int count = folderManager.filterByFolder(pdfList, fName).size();
                addFolderRowToMenu(menuSheet, layoutFolderList, populateFoldersRef[0], fName, fName, count, true);
            }
        };

        populateFoldersRef[0].run();

        btnMenuCreateFolder.setOnClickListener(v -> {
            EditText input = new EditText(this);
            input.setHint("ফোল্ডারের নাম লিখুন");
            input.setPadding(48, 32, 48, 32);

            new MaterialAlertDialogBuilder(this)
                    .setTitle("নতুন ফোল্ডার তৈরি করুন")
                    .setView(input)
                    .setPositiveButton("তৈরি করুন", (dialog, which) -> {
                        String name = input.getText().toString().trim();
                        if (!name.isEmpty()) {
                            folderManager.createFolder(name);
                            populateFoldersRef[0].run();
                            Toast.makeText(this, "ফোল্ডার '" + name + "' তৈরি হয়েছে", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("বাতিল", null)
                    .show();
        });

        menuSheet.setContentView(sheetView);
        menuSheet.show();
    }

    private void addFolderRowToMenu(BottomSheetDialog sheet, LinearLayout container, Runnable refreshFolders, String folderId, String displayName, int count, boolean canDelete) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_folder_row, container, false);
        TextView tvName = row.findViewById(R.id.tvFolderName);
        TextView tvCount = row.findViewById(R.id.tvFolderCount);
        ImageView ivCheck = row.findViewById(R.id.ivFolderSelectedCheck);
        ImageButton btnFolderDelete = row.findViewById(R.id.btnFolderDelete);

        tvName.setText(displayName);
        tvCount.setText(String.valueOf(count));

        boolean isActive = folderId.equalsIgnoreCase(currentSelectedFolder);
        ivCheck.setVisibility(isActive ? View.VISIBLE : View.GONE);

        btnFolderDelete.setVisibility(canDelete ? View.VISIBLE : View.GONE);
        if (canDelete) {
            btnFolderDelete.setOnClickListener(v -> {
                new MaterialAlertDialogBuilder(this)
                        .setTitle("ফোল্ডার মুছে ফেলা")
                        .setMessage("আপনি কি নিশ্চিত যে '" + displayName + "' ফোল্ডারটি মুছে ফেলতে চান?")
                        .setPositiveButton("মুছে ফেলুন", (dialog, which) -> {
                            folderManager.deleteFolder(folderId);
                            if (folderId.equalsIgnoreCase(currentSelectedFolder)) {
                                clearFolderFilter();
                            }
                            if (refreshFolders != null) {
                                refreshFolders.run();
                            }
                            Toast.makeText(this, "ফোল্ডার '" + displayName + "' মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("বাতিল", null)
                        .show();
            });
        }

        row.setOnClickListener(v -> {
            sheet.dismiss();
            switchToHomeTab();
            filterByFolder(folderId);
        });

        container.addView(row);
    }

    private void initSwipeGesture() {
        swipeGestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            private static final int SWIPE_MIN_DISTANCE = 80;
            private static final int SWIPE_THRESHOLD_VELOCITY = 100;

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float diffX = e2.getX() - e1.getX();
                float diffY = e2.getY() - e1.getY();

                if (diffX > SWIPE_MIN_DISTANCE && Math.abs(diffX) > Math.abs(diffY) * 1.2f && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                    if (pdfAdapter == null || !pdfAdapter.isSelectionMode()) {
                        showMainMenuBottomSheet();
                        return true;
                    }
                }
                return false;
            }
        });
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (swipeGestureDetector != null) {
            swipeGestureDetector.onTouchEvent(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    private void filterByFolder(String folderName) {
        currentSelectedFolder = folderName;
        if (folderName == null || FolderManager.FOLDER_ALL.equalsIgnoreCase(folderName)) {
            layoutActiveFolderBanner.setVisibility(View.GONE);
            pdfAdapter.setPdfList(pdfList);
            tvSubtitleCount.setText(String.format("%d documents found", pdfList.size()));
        } else {
            layoutActiveFolderBanner.setVisibility(View.VISIBLE);
            chipActiveFolder.setText(folderName);
            List<PdfFile> filtered = folderManager.filterByFolder(pdfList, folderName);
            pdfAdapter.setPdfList(filtered);
            tvSubtitleCount.setText(String.format("%s (%d documents)", folderName, filtered.size()));
        }
        updateFolderChipsSelection();
    }

    private void clearFolderFilter() {
        filterByFolder(FolderManager.FOLDER_ALL);
    }

    private void refreshFolderChips() {
        if (chipGroupFolders == null) return;
        chipGroupFolders.removeAllViews();

        // 1. All
        addFolderChipToBar(FolderManager.FOLDER_ALL, "সব (" + pdfList.size() + ")", false);

        // 2. Favorites
        int favCount = folderManager.filterByFolder(pdfList, FolderManager.FOLDER_FAVORITES).size();
        addFolderChipToBar(FolderManager.FOLDER_FAVORITES, "★ ফেভারিট (" + favCount + ")", false);

        // 3. Folders
        List<String> folders = folderManager.getAllFolders();
        for (String fName : folders) {
            int count = folderManager.filterByFolder(pdfList, fName).size();
            addFolderChipToBar(fName, fName + " (" + count + ")", true);
        }
    }

    private void addFolderChipToBar(String folderId, String label, boolean isCustomOrDeletable) {
        Chip chip = new Chip(this);
        chip.setText(label);
        chip.setCheckable(true);
        chip.setClickable(true);
        boolean isSelected = folderId.equalsIgnoreCase(currentSelectedFolder);
        chip.setChecked(isSelected);

        chip.setOnClickListener(v -> filterByFolder(folderId));

        if (isCustomOrDeletable && !FolderManager.FOLDER_ALL.equalsIgnoreCase(folderId) && !FolderManager.FOLDER_FAVORITES.equalsIgnoreCase(folderId)) {
            chip.setOnLongClickListener(v -> {
                showManageFolderDialog(folderId);
                return true;
            });
        }

        chipGroupFolders.addView(chip);
    }

    private void updateFolderChipsSelection() {
        if (chipGroupFolders == null) return;
        for (int i = 0; i < chipGroupFolders.getChildCount(); i++) {
            View child = chipGroupFolders.getChildAt(i);
            if (child instanceof Chip) {
                Chip c = (Chip) child;
                String text = c.getText().toString();
                if (FolderManager.FOLDER_ALL.equalsIgnoreCase(currentSelectedFolder)) {
                    c.setChecked(text.startsWith("সব"));
                } else if (FolderManager.FOLDER_FAVORITES.equalsIgnoreCase(currentSelectedFolder)) {
                    c.setChecked(text.startsWith("★"));
                } else {
                    c.setChecked(text.startsWith(currentSelectedFolder));
                }
            }
        }
    }

    private void showCreateFolderDialog(Runnable onCreated) {
        EditText input = new EditText(this);
        input.setHint("ফোল্ডারের নাম লিখুন");
        input.setPadding(48, 32, 48, 32);

        new MaterialAlertDialogBuilder(this)
                .setTitle("নতুন ফোল্ডার তৈরি করুন")
                .setView(input)
                .setPositiveButton("তৈরি করুন", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "ফোল্ডারের নাম খালি রাখা যাবে না", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    folderManager.createFolder(name);
                    refreshFolderChips();
                    Toast.makeText(this, "ফোল্ডার '" + name + "' তৈরি হয়েছে", Toast.LENGTH_SHORT).show();
                    filterByFolder(name);
                    if (onCreated != null) onCreated.run();
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void showManageFolderDialog(String folderId) {
        String[] options = new String[] { "নাম পরিবর্তন করুন (Rename)", "মুছে ফেলুন (Delete)" };
        new MaterialAlertDialogBuilder(this)
                .setTitle("ফোল্ডার: " + folderId)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        EditText input = new EditText(this);
                        input.setText(folderId);
                        input.setSelection(folderId.length());
                        input.setPadding(48, 32, 48, 32);

                        new MaterialAlertDialogBuilder(this)
                                .setTitle("ফোল্ডারের নাম পরিবর্তন")
                                .setView(input)
                                .setPositiveButton("সংরক্ষণ", (d, w) -> {
                                    String newName = input.getText().toString().trim();
                                    if (!newName.isEmpty() && !newName.equalsIgnoreCase(folderId)) {
                                        folderManager.renameFolder(folderId, newName);
                                        if (folderId.equalsIgnoreCase(currentSelectedFolder)) {
                                            currentSelectedFolder = newName;
                                        }
                                        refreshFolderChips();
                                        filterByFolder(currentSelectedFolder);
                                        Toast.makeText(this, "নাম পরিবর্তন হয়েছে: " + newName, Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .setNegativeButton("বাতিল", null)
                                .show();
                    } else if (which == 1) {
                        new MaterialAlertDialogBuilder(this)
                                .setTitle("ফোল্ডার মুছে ফেলুন")
                                .setMessage("আপনি কি নিশ্চিত যে '" + folderId + "' ফোল্ডারটি মুছে ফেলতে চান?")
                                .setPositiveButton("মুছে ফেলুন", (d, w) -> {
                                    folderManager.deleteFolder(folderId);
                                    if (folderId.equalsIgnoreCase(currentSelectedFolder)) {
                                        clearFolderFilter();
                                    } else {
                                        refreshFolderChips();
                                    }
                                    Toast.makeText(this, "ফোল্ডার মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show();
                                })
                                .setNegativeButton("বাতিল", null)
                                .show();
                    }
                })
                .show();
    }

    private void showMoveToFolderDialog(PdfFile pdfFile) {
        List<String> folderList = new ArrayList<>();
        folderList.addAll(folderManager.getAllFolders());
        folderList.add("+ নতুন ফোল্ডার তৈরি করুন");

        String[] items = folderList.toArray(new String[0]);
        new MaterialAlertDialogBuilder(this)
                .setTitle("ফোল্ডারে রাখুন")
                .setItems(items, (dialog, which) -> {
                    if (which == items.length - 1) {
                        showCreateFolderDialog(() -> {
                            List<String> updated = folderManager.getAllFolders();
                            if (!updated.isEmpty()) {
                                String newlyCreated = updated.get(updated.size() - 1);
                                String id = pdfFile.getPath() != null ? pdfFile.getPath() : pdfFile.getName();
                                folderManager.assignPdfToFolder(id, newlyCreated);
                                refreshFolderChips();
                                filterByFolder(newlyCreated);
                                Toast.makeText(this, "ফাইলটি '" + newlyCreated + "' ফোল্ডারে রাখা হয়েছে", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        String chosenFolder = items[which];
                        String id = pdfFile.getPath() != null ? pdfFile.getPath() : pdfFile.getName();
                        folderManager.assignPdfToFolder(id, chosenFolder);
                        refreshFolderChips();
                        if (chosenFolder.equalsIgnoreCase(currentSelectedFolder)) {
                            filterByFolder(chosenFolder);
                        }
                        Toast.makeText(this, "ফাইলটি '" + chosenFolder + "' ফোল্ডারে রাখা হয়েছে", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("বাতিল", null)
                .show();
    }

    private void showContextualBottomSheet(PdfFile pdfFile) {
        BottomSheetDialog bottomSheet = new BottomSheetDialog(this, R.style.RoundedBottomSheetDialog);
        View sheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_pdf_options, null);
        bottomSheet.setContentView(sheetView);

        TextView tvName = sheetView.findViewById(R.id.tvSheetPdfName);
        TextView tvDetails = sheetView.findViewById(R.id.tvSheetPdfDetails);

        tvName.setText(pdfFile.getName());
        tvDetails.setText(String.format("%s • %s", pdfFile.getFormattedSize(), pdfFile.getFormattedDate()));

        View actionMove = sheetView.findViewById(R.id.actionMoveToFolder);
        if (actionMove != null) {
            actionMove.setOnClickListener(v -> {
                bottomSheet.dismiss();
                showMoveToFolderDialog(pdfFile);
            });
        }

        sheetView.findViewById(R.id.actionOpenWith).setOnClickListener(v -> {
            bottomSheet.dismiss();
            openWithExternalApp(pdfFile);
        });

        sheetView.findViewById(R.id.actionCut).setOnClickListener(v -> {
            bottomSheet.dismiss();
            Toast.makeText(this, "Cut: \"" + pdfFile.getName() + "\"", Toast.LENGTH_SHORT).show();
        });

        sheetView.findViewById(R.id.actionCopy).setOnClickListener(v -> {
            bottomSheet.dismiss();
            Toast.makeText(this, "Copied: \"" + pdfFile.getName() + "\"", Toast.LENGTH_SHORT).show();
        });

        sheetView.findViewById(R.id.actionDelete).setOnClickListener(v -> {
            bottomSheet.dismiss();
            showDeleteConfirmDialog(pdfFile);
        });

        sheetView.findViewById(R.id.actionRename).setOnClickListener(v -> {
            bottomSheet.dismiss();
            showRenameDialog(pdfFile);
        });

        sheetView.findViewById(R.id.actionCompress).setOnClickListener(v -> {
            bottomSheet.dismiss();
            compressPdfFile(pdfFile);
        });

        sheetView.findViewById(R.id.actionShare).setOnClickListener(v -> {
            bottomSheet.dismiss();
            sharePdfFile(pdfFile);
        });

        sheetView.findViewById(R.id.actionCopyPath).setOnClickListener(v -> {
            bottomSheet.dismiss();
            copyFilePathToClipboard(pdfFile);
        });

        sheetView.findViewById(R.id.actionCreateShortcut).setOnClickListener(v -> {
            bottomSheet.dismiss();
            createDesktopShortcut(pdfFile);
        });

        sheetView.findViewById(R.id.actionProperties).setOnClickListener(v -> {
            bottomSheet.dismiss();
            showPropertiesDialog(pdfFile);
        });

        bottomSheet.show();
    }

    private void openWithExternalApp(PdfFile pdfFile) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(pdfFile.getUri(), "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, getString(R.string.open_with)));
        } catch (Exception e) {
            Toast.makeText(this, "No external application found for PDF", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmDialog(PdfFile pdfFile) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete)
                .setMessage("Are you sure you want to delete \"" + pdfFile.getName() + "\"?")
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    boolean deleted = false;
                    if (pdfFile.getPath() != null && !pdfFile.getPath().isEmpty()) {
                        File file = new File(pdfFile.getPath());
                        if (file.exists()) {
                            deleted = file.delete();
                        }
                    }
                    if (!deleted && pdfFile.getUri() != null) {
                        try {
                            getContentResolver().delete(pdfFile.getUri(), null, null);
                            deleted = true;
                        } catch (Exception ignored) {}
                    }
                    Toast.makeText(this, "Deleted " + pdfFile.getName(), Toast.LENGTH_SHORT).show();
                    loadPdfFiles();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showRenameDialog(PdfFile pdfFile) {
        EditText input = new EditText(this);
        input.setText(pdfFile.getName());
        input.setSelection(pdfFile.getName().lastIndexOf(".") > 0 ? pdfFile.getName().lastIndexOf(".") : pdfFile.getName().length());
        input.setPadding(48, 32, 48, 32);

        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.rename)
                .setView(input)
                .setPositiveButton(R.string.confirm, (dialog, which) -> {
                    String newName = input.getText().toString().trim();
                    if (!newName.isEmpty() && !newName.equals(pdfFile.getName())) {
                        if (pdfFile.getPath() != null && !pdfFile.getPath().isEmpty()) {
                            File oldFile = new File(pdfFile.getPath());
                            File newFile = new File(oldFile.getParent(), newName);
                            if (oldFile.renameTo(newFile)) {
                                Toast.makeText(this, "Renamed to " + newName, Toast.LENGTH_SHORT).show();
                                loadPdfFiles();
                                return;
                            }
                        }
                        pdfFile.setName(newName);
                        pdfAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Renamed to " + newName, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void compressPdfFile(PdfFile pdfFile) {
        progressBar.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                Thread.sleep(800);
            } catch (InterruptedException ignored) {}

            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(this, "Compressed " + pdfFile.getName() + " (Reduced by 24%)", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    private void sharePdfFile(PdfFile pdfFile) {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");
            shareIntent.putExtra(Intent.EXTRA_STREAM, pdfFile.getUri());
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, pdfFile.getName());
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, getString(R.string.share)));
        } catch (Exception e) {
            Toast.makeText(this, "Failed to share PDF", Toast.LENGTH_SHORT).show();
        }
    }

    private void copyFilePathToClipboard(PdfFile pdfFile) {
        String path = (pdfFile.getPath() != null && !pdfFile.getPath().isEmpty())
                ? pdfFile.getPath()
                : (pdfFile.getUri() != null ? pdfFile.getUri().toString() : pdfFile.getName());

        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("PDF Path", path);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "Path copied to clipboard", Toast.LENGTH_SHORT).show();
        }
    }

    private void createDesktopShortcut(PdfFile pdfFile) {
        if (ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            Intent shortcutIntent = new Intent(this, PdfViewerActivity.class);
            shortcutIntent.setAction(Intent.ACTION_VIEW);
            shortcutIntent.putExtra(PdfViewerActivity.EXTRA_PDF_PATH, pdfFile.getPath());
            shortcutIntent.putExtra(PdfViewerActivity.EXTRA_PDF_NAME, pdfFile.getName());
            if (pdfFile.getUri() != null) {
                shortcutIntent.putExtra(PdfViewerActivity.EXTRA_PDF_URI, pdfFile.getUri().toString());
            }

            ShortcutInfoCompat pinShortcutInfo = new ShortcutInfoCompat.Builder(this, "pdf_" + pdfFile.getId())
                    .setShortLabel(pdfFile.getName())
                    .setIcon(IconCompat.createWithResource(this, R.drawable.ic_pdf_file))
                    .setIntent(shortcutIntent)
                    .build();

            ShortcutManagerCompat.requestPinShortcut(this, pinShortcutInfo, null);
            Toast.makeText(this, "Pinned \"" + pdfFile.getName() + "\" to Home Screen!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Shortcut requested for Home Screen", Toast.LENGTH_SHORT).show();
        }
    }

    private void showPropertiesDialog(PdfFile pdfFile) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_pdf_properties);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        TextView tvName = dialog.findViewById(R.id.tvPropFileName);
        TextView tvPath = dialog.findViewById(R.id.tvPropFilePath);
        TextView tvSize = dialog.findViewById(R.id.tvPropFileSize);
        TextView tvDate = dialog.findViewById(R.id.tvPropFileDate);
        TextView tvPageCount = dialog.findViewById(R.id.tvPropPageCount);
        MaterialButton btnClose = dialog.findViewById(R.id.btnCloseProperties);

        tvName.setText(pdfFile.getName());
        tvPath.setText(pdfFile.getPath() != null && !pdfFile.getPath().isEmpty() ? pdfFile.getPath() : pdfFile.getUri().toString());
        tvSize.setText(String.format("%s (%d bytes)", pdfFile.getFormattedSize(), pdfFile.getSize()));
        tvDate.setText(pdfFile.getFormattedFullDate());

        new Thread(() -> {
            int pages = PdfUtils.getPageCount(this, pdfFile.getUri());
            runOnUiThread(() -> tvPageCount.setText(pages + (pages == 1 ? " Page" : " Pages")));
        }).start();

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    @Override
    protected void onDestroy() {
        if (downloadPdfAdapter != null) {
            downloadPdfAdapter.unregisterListener();
        }
        super.onDestroy();
    }
}
