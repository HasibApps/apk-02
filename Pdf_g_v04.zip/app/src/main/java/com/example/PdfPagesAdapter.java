package com.example;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPagesAdapter extends RecyclerView.Adapter<PdfPagesAdapter.PageViewHolder> {

    public interface OnPageCropClickListener {
        void onPageCropClick(int pageIndex, Bitmap pageBitmap);
    }

    public interface OnPageLensClickListener {
        void onPageLensClick(int pageIndex, Bitmap pageBitmap);
    }

    private final Context context;
    private final PdfRenderer pdfRenderer;
    private final int totalPages;
    private final OnPageCropClickListener cropClickListener;
    private final OnPageLensClickListener lensClickListener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService renderExecutor = Executors.newFixedThreadPool(2);
    private final LruCache<Integer, Bitmap> bitmapCache;

    public PdfPagesAdapter(
            Context context,
            PdfRenderer pdfRenderer,
            int totalPages,
            OnPageCropClickListener cropClickListener,
            OnPageLensClickListener lensClickListener
    ) {
        this.context = context;
        this.pdfRenderer = pdfRenderer;
        this.totalPages = totalPages;
        this.cropClickListener = cropClickListener;
        this.lensClickListener = lensClickListener;

        // Cache up to 12 rendered page bitmaps
        final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        final int cacheSize = Math.max(1024 * 16, maxMemory / 6);
        bitmapCache = new LruCache<Integer, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(Integer key, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };
    }

    @NonNull
    @Override
    public PageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_pdf_page_item, parent, false);
        return new PageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PageViewHolder holder, int position) {
        holder.tvPageNumber.setText(String.format("Page %d", position + 1));

        Bitmap cached = bitmapCache.get(position);
        if (cached != null) {
            holder.progressBar.setVisibility(View.GONE);
            holder.ivPage.setImageBitmap(cached);
        } else {
            holder.progressBar.setVisibility(View.VISIBLE);
            holder.ivPage.setImageDrawable(null);

            final int displayWidth = Math.max(1080, context.getResources().getDisplayMetrics().widthPixels);
            renderExecutor.execute(() -> {
                Bitmap rendered = renderPageBitmap(position, displayWidth);
                if (rendered != null) {
                    bitmapCache.put(position, rendered);
                    mainHandler.post(() -> {
                        if (holder.getBindingAdapterPosition() == position) {
                            holder.progressBar.setVisibility(View.GONE);
                            holder.ivPage.setImageBitmap(rendered);
                        }
                    });
                }
            });
        }

        // Crop page button
        holder.btnCropPage.setOnClickListener(v -> {
            if (cropClickListener != null) {
                Bitmap bmp = bitmapCache.get(position);
                if (bmp == null) {
                    int width = Math.max(1080, context.getResources().getDisplayMetrics().widthPixels);
                    bmp = renderPageBitmap(position, width);
                }
                cropClickListener.onPageCropClick(position, bmp);
            }
        });

        // Google Lens button (Screenshot_20260924-073419.png / Screenshot_20260918-190034.png)
        View.OnClickListener lensAction = v -> {
            if (lensClickListener != null) {
                Bitmap bmp = bitmapCache.get(position);
                if (bmp == null) {
                    int width = Math.max(1200, context.getResources().getDisplayMetrics().widthPixels * 3 / 2);
                    bmp = renderPageBitmap(position, width);
                }
                lensClickListener.onPageLensClick(position, bmp);
            }
        };

        if (holder.btnPageDirectLens != null) {
            holder.btnPageDirectLens.setOnClickListener(lensAction);
        }
        if (holder.btnLensPage != null) {
            holder.btnLensPage.setOnClickListener(lensAction);
        }
    }

    public synchronized Bitmap renderPageBitmap(int pageIndex, int targetWidth) {
        if (pdfRenderer == null || pageIndex < 0 || pageIndex >= totalPages) return null;

        PdfRenderer.Page page = null;
        try {
            page = pdfRenderer.openPage(pageIndex);
            int originalW = page.getWidth();
            int originalH = page.getHeight();

            if (targetWidth <= 0) targetWidth = 1080;
            float scale = (float) targetWidth / originalW;
            int width = targetWidth;
            int height = (int) (originalH * scale);

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);

            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (page != null) {
                try {
                    page.close();
                } catch (Exception ignored) {}
            }
        }
    }

    public Bitmap getCachedBitmap(int position) {
        return bitmapCache.get(position);
    }

    @Override
    public int getItemCount() {
        return totalPages;
    }

    public void release() {
        try {
            renderExecutor.shutdownNow();
            bitmapCache.evictAll();
        } catch (Exception ignored) {}
    }

    static class PageViewHolder extends RecyclerView.ViewHolder {
        TextView tvPageNumber;
        ImageButton btnPageDirectLens;
        View btnLensPage;
        MaterialButton btnCropPage;
        ImageView ivPage;
        ProgressBar progressBar;

        public PageViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPageNumber = itemView.findViewById(R.id.tvItemPageNumber);
            btnPageDirectLens = itemView.findViewById(R.id.btnPageDirectLens);
            btnLensPage = itemView.findViewById(R.id.btnLensThisPage);
            btnCropPage = itemView.findViewById(R.id.btnCropThisPage);
            ivPage = itemView.findViewById(R.id.ivPdfPageItem);
            progressBar = itemView.findViewById(R.id.pageItemProgressBar);
        }
    }
}
