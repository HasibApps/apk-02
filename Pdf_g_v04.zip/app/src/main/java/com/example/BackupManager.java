package com.example;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Set;

public class BackupManager {

    public interface BackupCallback {
        void onSuccess(String message);
        void onError(String error);
    }

    public static JSONObject generateBackupJson(Context context) {
        JSONObject root = new JSONObject();
        try {
            root.put("app", "PDF Gallery");
            root.put("version", 1);
            root.put("timestamp", System.currentTimeMillis());

            // 1. Favorites
            FavoritesManager favMgr = new FavoritesManager(context);
            JSONArray favArray = new JSONArray();
            for (String key : favMgr.getAllFavoriteKeys()) {
                favArray.put(key);
            }
            root.put("favorites", favArray);

            // 2. URL items & downloads along with each PDF's notes
            UrlPdfManager urlMgr = new UrlPdfManager(context);
            PdfNotesManager notesMgr = new PdfNotesManager(context);
            List<UrlPdfItem> items = urlMgr.getAllItems();
            JSONArray urlArray = new JSONArray();
            for (UrlPdfItem item : items) {
                JSONObject itemJson = item.toJson();

                // Retrieve notes created for this URL PDF item
                String col1 = null;
                String col2 = null;

                if (item.getLocalFilePath() != null && notesMgr.hasCustomNotes(item.getLocalFilePath())) {
                    col1 = notesMgr.getNoteCol1ForPdf(item.getLocalFilePath());
                    col2 = notesMgr.getNoteCol2ForPdf(item.getLocalFilePath());
                } else if (item.getTitle() != null && notesMgr.hasCustomNotes(item.getTitle())) {
                    col1 = notesMgr.getNoteCol1ForPdf(item.getTitle());
                    col2 = notesMgr.getNoteCol2ForPdf(item.getTitle());
                } else if (item.getId() != null && notesMgr.hasCustomNotes(item.getId())) {
                    col1 = notesMgr.getNoteCol1ForPdf(item.getId());
                    col2 = notesMgr.getNoteCol2ForPdf(item.getId());
                } else if (item.getOriginalUrl() != null && notesMgr.hasCustomNotes(item.getOriginalUrl())) {
                    col1 = notesMgr.getNoteCol1ForPdf(item.getOriginalUrl());
                    col2 = notesMgr.getNoteCol2ForPdf(item.getOriginalUrl());
                } else if (item.getLocalFilePath() != null) {
                    col1 = notesMgr.getNoteCol1ForPdf(item.getLocalFilePath());
                    col2 = notesMgr.getNoteCol2ForPdf(item.getLocalFilePath());
                }

                if (col1 != null || col2 != null) {
                    itemJson.put("note_col1", col1 != null ? col1 : "");
                    itemJson.put("note_col2", col2 != null ? col2 : "");
                    itemJson.put("notes", (col1 != null ? col1 : "") + "\n\n" + (col2 != null ? col2 : ""));
                }

                urlArray.put(itemJson);
            }
            root.put("url_pdf_items", urlArray);

            // 3. Custom Folders
            FolderManager folderMgr = new FolderManager(context);
            JSONArray foldersArray = new JSONArray();
            for (String f : folderMgr.getAllFolders()) {
                foldersArray.put(f);
            }
            root.put("folders", foldersArray);

            // 4. All PDF Notes in the application
            root.put("all_pdf_notes", notesMgr.exportAllNotesAsJson());

        } catch (Exception ignored) {}
        return root;
    }

    public static boolean exportBackupToUri(Context context, Uri uri) {
        try {
            JSONObject json = generateBackupJson(context);
            String jsonStr = json.toString(2);
            FileOutputStream fos = (FileOutputStream) context.getContentResolver().openOutputStream(uri);
            if (fos != null) {
                fos.write(jsonStr.getBytes("UTF-8"));
                fos.flush();
                fos.close();
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static boolean importBackupFromUri(Context context, Uri uri) {
        try {
            InputStream is = context.getContentResolver().openInputStream(uri);
            if (is == null) return false;
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            is.close();

            JSONObject root = new JSONObject(sb.toString());

            // 1. Restore favorites
            if (root.has("favorites")) {
                JSONArray favs = root.getJSONArray("favorites");
                FavoritesManager favMgr = new FavoritesManager(context);
                Set<String> set = favMgr.getAllFavoriteKeys();
                for (int i = 0; i < favs.length(); i++) {
                    set.add(favs.getString(i));
                }
                favMgr.restoreFavoriteKeys(set);
            }

            PdfNotesManager notesMgr = new PdfNotesManager(context);

            // 2. Restore URL items and their per-PDF notes
            if (root.has("url_pdf_items")) {
                JSONArray urls = root.getJSONArray("url_pdf_items");
                UrlPdfManager urlMgr = new UrlPdfManager(context);
                for (int i = 0; i < urls.length(); i++) {
                    JSONObject itemObj = urls.getJSONObject(i);
                    UrlPdfItem item = UrlPdfItem.fromJson(itemObj);
                    if (item != null) {
                        urlMgr.saveItem(item);

                        // Restore notes associated with this URL PDF
                        String col1 = itemObj.optString("note_col1", null);
                        String col2 = itemObj.optString("note_col2", null);
                        String fullNotes = itemObj.optString("notes", null);

                        if (col1 != null || col2 != null || fullNotes != null) {
                            if (col1 == null) col1 = "";
                            if (col2 == null) col2 = "";
                            if (item.getLocalFilePath() != null && !item.getLocalFilePath().isEmpty()) {
                                notesMgr.saveTwoColumnNotes(item.getLocalFilePath(), col1, col2);
                            }
                            if (item.getTitle() != null && !item.getTitle().isEmpty()) {
                                notesMgr.saveTwoColumnNotes(item.getTitle(), col1, col2);
                            }
                            if (item.getId() != null && !item.getId().isEmpty()) {
                                notesMgr.saveTwoColumnNotes(item.getId(), col1, col2);
                            }
                            if (item.getOriginalUrl() != null && !item.getOriginalUrl().isEmpty()) {
                                notesMgr.saveTwoColumnNotes(item.getOriginalUrl(), col1, col2);
                            }
                        }
                    }
                }
            }

            // 3. Restore folders
            if (root.has("folders")) {
                JSONArray folders = root.getJSONArray("folders");
                FolderManager folderMgr = new FolderManager(context);
                for (int i = 0; i < folders.length(); i++) {
                    folderMgr.createFolder(folders.getString(i));
                }
            }

            // 4. Restore all PDF notes
            if (root.has("all_pdf_notes")) {
                JSONArray notesArray = root.getJSONArray("all_pdf_notes");
                notesMgr.restoreNotesFromJson(notesArray);
            }

            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
