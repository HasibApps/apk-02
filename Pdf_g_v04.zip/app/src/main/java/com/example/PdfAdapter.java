package com.example;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfAdapter extends RecyclerView.Adapter<PdfAdapter.PdfViewHolder> {

    public interface OnPdfActionListener {
        void onPdfClick(PdfFile pdfFile);
        void onMenuClick(PdfFile pdfFile, View anchorView);
        void onSelectionChanged(int selectedCount);
        void onFavoriteToggle(PdfFile pdfFile, boolean isFavorite);
        void onDeleteClick(PdfFile pdfFile);
    }

    private final Context context;
    private final FavoritesManager favoritesManager;
    private final List<PdfFile> originalList = new ArrayList<>();
    private final List<PdfFile> displayedList = new ArrayList<>();
    private final Set<PdfFile> selectedFiles = new HashSet<>();
    private boolean isSelectionMode = false;
    private final OnPdfActionListener listener;

    private final ExecutorService thumbnailExecutor = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<String, Bitmap> thumbnailCache = new ConcurrentHashMap<>();

    public PdfAdapter(Context context, OnPdfActionListener listener) {
        this.context = context;
        this.listener = listener;
        this.favoritesManager = new FavoritesManager(context);
    }

    public void setPdfList(List<PdfFile> list) {
        originalList.clear();
        displayedList.clear();
        if (list != null) {
            originalList.addAll(list);
            displayedList.addAll(list);
        }
        notifyDataSetChanged();
    }

    public void filter(String query) {
        displayedList.clear();
        if (query == null || query.trim().isEmpty()) {
            displayedList.addAll(originalList);
        } else {
            String lower = query.toLowerCase().trim();
            for (PdfFile file : originalList) {
                if (file.getName().toLowerCase().contains(lower)) {
                    displayedList.add(file);
                }
            }
        }
        notifyDataSetChanged();
    }

    public boolean isSelectionMode() {
        return isSelectionMode;
    }

    public void startSelectionMode(PdfFile initialFile) {
        isSelectionMode = true;
        selectedFiles.clear();
        if (initialFile != null) {
            selectedFiles.add(initialFile);
        }
        notifyDataSetChanged();
        if (listener != null) {
            listener.onSelectionChanged(selectedFiles.size());
        }
    }

    public void clearSelectionMode() {
        isSelectionMode = false;
        selectedFiles.clear();
        notifyDataSetChanged();
        if (listener != null) {
            listener.onSelectionChanged(0);
        }
    }

    public List<PdfFile> getSelectedFiles() {
        return new ArrayList<>(selectedFiles);
    }

    private void toggleSelection(PdfFile file) {
        if (selectedFiles.contains(file)) {
            selectedFiles.remove(file);
            if (selectedFiles.isEmpty()) {
                clearSelectionMode();
                return;
            }
        } else {
            selectedFiles.add(file);
        }
        notifyDataSetChanged();
        if (listener != null) {
            listener.onSelectionChanged(selectedFiles.size());
        }
    }

    @NonNull
    @Override
    public PdfViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pdf_file, parent, false);
        return new PdfViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PdfViewHolder holder, int position) {
        PdfFile pdfFile = displayedList.get(position);
        boolean isSelected = selectedFiles.contains(pdfFile);

        holder.tvPdfTitle.setText(pdfFile.getName());
        holder.tvPdfDate.setText(pdfFile.getFormattedDate());
        holder.tvPdfSize.setText(PdfUtils.toBengaliDigits(pdfFile.getFormattedSize()));

        // Page count ("পৃষ্ঠা N") - computed once in the background and cached
        if (pdfFile.getPageCount() > 0) {
            holder.tvPdfPages.setText(PdfUtils.toBengaliDigits("পৃষ্ঠা " + pdfFile.getPageCount()));
            holder.tvPdfPages.setVisibility(View.VISIBLE);
        } else {
            holder.tvPdfPages.setVisibility(View.INVISIBLE);
            final Uri countUri = pdfFile.getUri();
            if (countUri != null) {
                thumbnailExecutor.execute(() -> {
                    int pages = PdfUtils.getPageCount(context, countUri);
                    if (pages > 0) {
                        pdfFile.setPageCount(pages);
                        mainHandler.post(() -> {
                            int pos = holder.getBindingAdapterPosition();
                            if (pos != RecyclerView.NO_POSITION && pos < displayedList.size()
                                    && displayedList.get(pos) == pdfFile) {
                                holder.tvPdfPages.setText(PdfUtils.toBengaliDigits("পৃষ্ঠা " + pages));
                                holder.tvPdfPages.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                });
            }
        }

        // Thumbnail or Icon
        String cacheKey = (pdfFile.getPath() != null && !pdfFile.getPath().isEmpty())
                ? pdfFile.getPath()
                : (pdfFile.getUri() != null ? pdfFile.getUri().toString() : String.valueOf(pdfFile.getId()));

        holder.ivPdfIcon.setVisibility(View.VISIBLE);
        holder.ivPdfThumbnail.setVisibility(View.GONE);

        if (thumbnailCache.containsKey(cacheKey)) {
            Bitmap cachedBitmap = thumbnailCache.get(cacheKey);
            if (cachedBitmap != null) {
                holder.ivPdfThumbnail.setImageBitmap(cachedBitmap);
                holder.ivPdfThumbnail.setVisibility(View.VISIBLE);
                holder.ivPdfIcon.setVisibility(View.GONE);
            }
        } else {
            holder.ivPdfThumbnail.setImageDrawable(null);
            final Uri uri = pdfFile.getUri();
            if (uri != null) {
                thumbnailExecutor.execute(() -> {
                    Bitmap bmp = PdfUtils.renderPageToBitmap(context, uri, 0, 120);
                    if (bmp != null) {
                        thumbnailCache.put(cacheKey, bmp);
                        mainHandler.post(() -> {
                            int currentPos = holder.getBindingAdapterPosition();
                            if (currentPos != RecyclerView.NO_POSITION && currentPos < displayedList.size()) {
                                if (displayedList.get(currentPos).getId() == pdfFile.getId()) {
                                    holder.ivPdfThumbnail.setImageBitmap(bmp);
                                    holder.ivPdfThumbnail.setVisibility(View.VISIBLE);
                                    holder.ivPdfIcon.setVisibility(View.GONE);
                                }
                            }
                        });
                    }
                });
            }
        }

        // Favorite state
        boolean isFav = favoritesManager.isFavorite(pdfFile);
        holder.btnFavorite.setImageResource(isFav ? R.drawable.ic_star_filled : R.drawable.ic_star_outline);

        holder.btnFavorite.setOnClickListener(v -> {
            boolean newFav = favoritesManager.toggleFavorite(pdfFile);
            holder.btnFavorite.setImageResource(newFav ? R.drawable.ic_star_filled : R.drawable.ic_star_outline);
            if (listener != null) {
                listener.onFavoriteToggle(pdfFile, newFav);
            }
        });

        // Selection mode UI styling
        if (isSelectionMode) {
            holder.btnMenu.setVisibility(View.GONE);
            holder.btnFavorite.setVisibility(View.GONE);
            holder.btnDelete.setVisibility(View.GONE);
            holder.cbPdfSelect.setVisibility(View.VISIBLE);
            holder.cbPdfSelect.setChecked(isSelected);
            holder.cardPdfItem.setStrokeWidth(isSelected ? 4 : 0);
            holder.cardPdfItem.setStrokeColor(isSelected ? 0xFF1976D2 : 0xFFE5E7EB);
        } else {
            holder.btnMenu.setVisibility(View.VISIBLE);
            holder.btnFavorite.setVisibility(View.VISIBLE);
            holder.btnDelete.setVisibility(View.VISIBLE);
            holder.cbPdfSelect.setVisibility(View.GONE);
            holder.cardPdfItem.setStrokeWidth(0);
            holder.cardPdfItem.setStrokeColor(0xFFE5E7EB);
        }

        // Click listeners
        holder.cardPdfItem.setOnClickListener(v -> {
            if (isSelectionMode) {
                toggleSelection(pdfFile);
            } else if (listener != null) {
                listener.onPdfClick(pdfFile);
            }
        });

        // Long click to start multi-select (Point 3)
        holder.cardPdfItem.setOnLongClickListener(v -> {
            if (!isSelectionMode) {
                startSelectionMode(pdfFile);
                return true;
            }
            return false;
        });

        // Trash button (bottom-right)
        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(pdfFile);
            }
        });

        // 3-dot overflow menu
        holder.btnMenu.setOnClickListener(v -> {
            if (listener != null) {
                listener.onMenuClick(pdfFile, v);
            }
        });
    }

    @Override
    public int getItemCount() {
        return displayedList.size();
    }

    public static class PdfViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView cardPdfItem;
        ImageView ivPdfIcon;
        ImageView ivPdfThumbnail;
        TextView tvPdfTitle;
        TextView tvPdfDate;
        TextView tvPdfSize;
        TextView tvPdfPages;
        ImageButton btnDelete;
        ImageButton btnFavorite;
        ImageButton btnMenu;
        CheckBox cbPdfSelect;

        public PdfViewHolder(@NonNull View itemView) {
            super(itemView);
            cardPdfItem = itemView.findViewById(R.id.cardPdfItem);
            ivPdfIcon = itemView.findViewById(R.id.ivPdfIcon);
            ivPdfThumbnail = itemView.findViewById(R.id.ivPdfThumbnail);
            tvPdfTitle = itemView.findViewById(R.id.tvPdfTitle);
            tvPdfDate = itemView.findViewById(R.id.tvPdfDate);
            tvPdfSize = itemView.findViewById(R.id.tvPdfSize);
            tvPdfPages = itemView.findViewById(R.id.tvPdfPages);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnFavorite = itemView.findViewById(R.id.btnFavorite);
            btnMenu = itemView.findViewById(R.id.btnMenu);
            cbPdfSelect = itemView.findViewById(R.id.cbPdfSelect);
        }
    }
}
