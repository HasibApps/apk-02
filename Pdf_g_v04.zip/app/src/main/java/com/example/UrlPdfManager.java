package com.example;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UrlPdfManager {

    public interface DriveTitleCallback {
        void onTitleFetched(String title);
        void onError(String error);
    }

    private static final String PREF_NAME = "pdf_url_items_prefs";
    private static final String KEY_ITEMS = "url_pdf_items_json";

    private static final ExecutorService titleExecutor = Executors.newFixedThreadPool(2);
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());
    private static final OkHttpClient titleHttpClient = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build();

    private final Context context;
    private final SharedPreferences prefs;

    public UrlPdfManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public synchronized List<UrlPdfItem> getAllItems() {
        List<UrlPdfItem> list = new ArrayList<>();
        String raw = prefs.getString(KEY_ITEMS, null);
        boolean needsResave = false;
        if (raw != null && !raw.trim().isEmpty()) {
            try {
                JSONArray array = new JSONArray(raw);
                for (int i = 0; i < array.length(); i++) {
                    UrlPdfItem item = UrlPdfItem.fromJson(array.getJSONObject(i));
                    if (item != null) {
                        // Strip unwanted prefixes like dl_url_1790159872928_
                        String cleanTitle = PdfUtils.cleanPdfName(item.getTitle());
                        if (!cleanTitle.equals(item.getTitle())) {
                            item.setTitle(cleanTitle);
                            needsResave = true;
                        }

                        // Verify if local file exists AND is a real valid PDF
                        if (item.getLocalFilePath() != null) {
                            File f = new File(item.getLocalFilePath());
                            // Clean up file on disk if it still has dl_url_ prefix
                            if (f.getName().toLowerCase().startsWith("dl_url_") || f.getName().toLowerCase().startsWith("dl_")) {
                                String cleanFileName = PdfUtils.cleanPdfName(f.getName());
                                File renamedFile = new File(f.getParentFile(), cleanFileName);
                                if (!renamedFile.exists() && f.exists() && f.renameTo(renamedFile)) {
                                    f = renamedFile;
                                    item.setLocalFilePath(renamedFile.getAbsolutePath());
                                    needsResave = true;
                                }
                            }

                            if (f.exists() && isValidPdfFile(f)) {
                                item.setDownloaded(true);
                                // Auto generate first page thumbnail if missing
                                if (item.getCoverImagePath() == null || !new File(item.getCoverImagePath()).exists()) {
                                    String autoThumb = PdfUtils.generateAndSaveFirstPageThumbnail(context, f, item.getId());
                                    if (autoThumb != null) {
                                        item.setCoverImagePath(autoThumb);
                                        needsResave = true;
                                    }
                                }
                            } else {
                                item.setDownloaded(false);
                                if (f.exists() && !isValidPdfFile(f)) {
                                    // Automatically delete corrupted/HTML error files from disk
                                    f.delete();
                                    item.setLocalFilePath(null);
                                    needsResave = true;
                                }
                            }
                        } else {
                            item.setDownloaded(false);
                            // If drive link has no cover, try fetching thumbnail in background
                            if (item.getCoverImagePath() == null || !new File(item.getCoverImagePath()).exists()) {
                                final UrlPdfItem finalItem = item;
                                Executors.newSingleThreadExecutor().execute(() -> {
                                    String thumb = PdfUtils.downloadDriveThumbnailIfAvailable(context, finalItem.getOriginalUrl(), finalItem.getId());
                                    if (thumb != null) {
                                        updateCoverImagePath(finalItem.getId(), thumb);
                                    }
                                });
                            }
                        }
                        list.add(item);
                    }
                }
            } catch (Exception ignored) {}
        }
        if (needsResave) {
            saveAll(list);
        }
        return list;
    }

    public synchronized void updateCoverImagePath(String itemId, String newCoverPath) {
        if (itemId == null) return;
        List<UrlPdfItem> items = getAllItems();
        boolean found = false;
        for (UrlPdfItem it : items) {
            if (itemId.equals(it.getId())) {
                it.setCoverImagePath(newCoverPath);
                found = true;
                break;
            }
        }
        if (found) {
            saveAll(items);
        }
    }

    /**
     * Checks if a file exists, has content, and starts with the standard PDF magic header (%PDF).
     */
    public static boolean isValidPdfFile(File file) {
        if (file == null || !file.exists() || file.length() < 100) return false;
        try (InputStream is = new FileInputStream(file)) {
            byte[] header = new byte[4];
            int read = is.read(header);
            return read == 4 && header[0] == 0x25 && header[1] == 0x50 && header[2] == 0x44 && header[3] == 0x46; // %PDF
        } catch (Exception ignored) {
            return false;
        }
    }

    public synchronized void saveItem(UrlPdfItem item) {
        if (item == null) return;
        List<UrlPdfItem> items = getAllItems();
        boolean found = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getId().equals(item.getId())) {
                items.set(i, item);
                found = true;
                break;
            }
        }
        if (!found) {
            items.add(0, item);
        }
        saveAll(items);
    }

    public synchronized void deleteItem(String id) {
        if (id == null) return;
        List<UrlPdfItem> items = getAllItems();
        UrlPdfItem toRemove = null;
        for (UrlPdfItem item : items) {
            if (item.getId().equals(id)) {
                toRemove = item;
                break;
            }
        }
        if (toRemove != null) {
            // delete local downloaded file if present
            if (toRemove.getLocalFilePath() != null) {
                try {
                    new File(toRemove.getLocalFilePath()).delete();
                } catch (Exception ignored) {}
            }
            if (toRemove.getCoverImagePath() != null) {
                try {
                    new File(toRemove.getCoverImagePath()).delete();
                } catch (Exception ignored) {}
            }
            items.remove(toRemove);
            saveAll(items);
        }
    }

    public synchronized void saveAll(List<UrlPdfItem> items) {
        JSONArray array = new JSONArray();
        if (items != null) {
            for (UrlPdfItem item : items) {
                array.put(item.toJson());
            }
        }
        prefs.edit().putString(KEY_ITEMS, array.toString()).apply();
    }

    public synchronized UrlPdfItem getItemById(String id) {
        for (UrlPdfItem item : getAllItems()) {
            if (item.getId().equals(id)) return item;
        }
        return null;
    }

    /**
     * Extracts Google Drive file ID from various link structures.
     */
    public static String extractGoogleDriveFileId(String url) {
        if (url == null) return null;
        String clean = url.trim();

        // 1. /file/d/{FILE_ID}
        Pattern p1 = Pattern.compile("/file/d/([a-zA-Z0-9_-]+)");
        Matcher m1 = p1.matcher(clean);
        if (m1.find()) return m1.group(1);

        // 2. /d/{FILE_ID}
        Pattern p2 = Pattern.compile("/d/([a-zA-Z0-9_-]+)");
        Matcher m2 = p2.matcher(clean);
        if (m2.find()) return m2.group(1);

        // 3. [?&]id={FILE_ID}
        Pattern p3 = Pattern.compile("[?&]id=([a-zA-Z0-9_-]+)");
        Matcher m3 = p3.matcher(clean);
        if (m3.find()) return m3.group(1);

        return null;
    }

    /**
     * Converts any Google Drive share URL into a direct download URL.
     * Uses modern drive.usercontent.google.com direct endpoint.
     */
    public static String extractDirectDownloadUrl(String url) {
        if (url == null) return "";
        String clean = url.trim();

        String fileId = extractGoogleDriveFileId(clean);
        if (fileId != null && !fileId.isEmpty()) {
            return "https://drive.usercontent.google.com/download?id=" + fileId + "&export=download&authuser=0&confirm=t";
        }

        return clean;
    }

    /**
     * Automatically fetches the real PDF title from Google Drive in background.
     */
    public static void fetchDriveTitleAsync(String rawUrl, DriveTitleCallback callback) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) {
            if (callback != null) callback.onError("Empty URL");
            return;
        }

        final String url = rawUrl.trim();
        titleExecutor.execute(() -> {
            String title = fetchDriveTitleInternal(url, 12);
            mainHandler.post(() -> {
                if (title != null && !title.isEmpty()) {
                    if (callback != null) callback.onTitleFetched(title);
                } else {
                    if (callback != null) callback.onError("Could not extract title");
                }
            });
        });
    }

    /**
     * Synchronous title extraction helper with timeout.
     */
    public static String fetchDriveTitleSync(String rawUrl, int timeoutSeconds) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) return null;
        return fetchDriveTitleInternal(rawUrl.trim(), timeoutSeconds);
    }

    private static String fetchDriveTitleInternal(String url, int timeoutSeconds) {
        String fileId = extractGoogleDriveFileId(url);
        if (fileId != null && !fileId.isEmpty()) {
            // Try Strategy 1: Fetch Google Drive public view page and extract og:title or <title>
            try {
                String viewUrl = "https://drive.google.com/file/d/" + fileId + "/view";
                Request request = new Request.Builder()
                        .url(viewUrl)
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                        .header("Accept-Language", "bn,en;q=0.9")
                        .build();

                Response response = titleHttpClient.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String html = response.body().string();

                    // Pattern A: <meta property="og:title" content="...">
                    Pattern pOg = Pattern.compile("<meta\\s+property=[\"']og:title[\"']\\s+content=[\"'](.*?)[\"']", Pattern.CASE_INSENSITIVE);
                    Matcher mOg = pOg.matcher(html);
                    if (mOg.find()) {
                        String clean = cleanExtractedTitle(mOg.group(1));
                        if (clean != null) return clean;
                    }

                    // Pattern B: <meta name="title" content="...">
                    Pattern pName = Pattern.compile("<meta\\s+name=[\"']title[\"']\\s+content=[\"'](.*?)[\"']", Pattern.CASE_INSENSITIVE);
                    Matcher mName = pName.matcher(html);
                    if (mName.find()) {
                        String clean = cleanExtractedTitle(mName.group(1));
                        if (clean != null) return clean;
                    }

                    // Pattern C: <title>FILENAME - Google Drive</title>
                    Pattern pTitle = Pattern.compile("<title>(.*?)</title>", Pattern.CASE_INSENSITIVE);
                    Matcher mTitle = pTitle.matcher(html);
                    if (mTitle.find()) {
                        String clean = cleanExtractedTitle(mTitle.group(1));
                        if (clean != null) return clean;
                    }

                    // Pattern D: JSON inside page: "title":"..."
                    Pattern pJson = Pattern.compile("\"title\":\"([^\"]+?\\.pdf)\"", Pattern.CASE_INSENSITIVE);
                    Matcher mJson = pJson.matcher(html);
                    if (mJson.find()) {
                        String clean = cleanExtractedTitle(mJson.group(1));
                        if (clean != null) return clean;
                    }
                }
            } catch (Exception ignored) {}

            // Try Strategy 2: Check Content-Disposition header via HEAD/GET on direct download
            try {
                String dlUrl = "https://drive.usercontent.google.com/download?id=" + fileId + "&export=download&authuser=0&confirm=t";
                Request req = new Request.Builder()
                        .url(dlUrl)
                        .header("Range", "bytes=0-1024")
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                        .build();

                Response resp = titleHttpClient.newCall(req).execute();
                String disposition = resp.header("Content-Disposition");
                if (disposition != null) {
                    String extracted = parseFilenameFromContentDisposition(disposition);
                    if (extracted != null) {
                        String clean = cleanExtractedTitle(extracted);
                        if (clean != null) return clean;
                    }
                }
            } catch (Exception ignored) {}
        }

        // Generic URL fallback: check if last path segment contains filename
        try {
            Uri uri = Uri.parse(url);
            String lastPath = uri.getLastPathSegment();
            if (lastPath != null && lastPath.toLowerCase().endsWith(".pdf")) {
                return cleanExtractedTitle(lastPath);
            }
        } catch (Exception ignored) {}

        return null;
    }

    public static String parseFilenameFromContentDisposition(String disposition) {
        if (disposition == null) return null;

        // 1. filename*=UTF-8''...
        Pattern pUtf = Pattern.compile("filename\\*=UTF-8''([^;\\r\\n]+)", Pattern.CASE_INSENSITIVE);
        Matcher mUtf = pUtf.matcher(disposition);
        if (mUtf.find()) {
            try {
                return URLDecoder.decode(mUtf.group(1), "UTF-8");
            } catch (Exception ignored) {}
        }

        // 2. filename="..."
        Pattern pQuoted = Pattern.compile("filename=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
        Matcher mQuoted = pQuoted.matcher(disposition);
        if (mQuoted.find()) {
            return mQuoted.group(1);
        }

        // 3. filename=...
        Pattern pPlain = Pattern.compile("filename=([^;\\s]+)", Pattern.CASE_INSENSITIVE);
        Matcher mPlain = pPlain.matcher(disposition);
        if (mPlain.find()) {
            return mPlain.group(1);
        }

        return null;
    }

    public static String cleanExtractedTitle(String rawTitle) {
        if (rawTitle == null) return null;
        String clean = rawTitle.trim();
        if (clean.isEmpty()) return null;

        // Decode URL percent-encoding
        try {
            if (clean.contains("%")) {
                clean = URLDecoder.decode(clean, "UTF-8");
            }
        } catch (Exception ignored) {}

        // Unescape common HTML entities
        clean = clean.replace("&quot;", "\"")
                     .replace("&apos;", "'")
                     .replace("&#39;", "'")
                     .replace("&amp;", "&")
                     .replace("&lt;", "<")
                     .replace("&gt;", ">");

        // Remove trailing " - Google Drive" or " - Google Docs"
        if (clean.endsWith(" - Google Drive")) {
            clean = clean.substring(0, clean.length() - " - Google Drive".length()).trim();
        }
        if (clean.endsWith(" - Google Docs")) {
            clean = clean.substring(0, clean.length() - " - Google Docs".length()).trim();
        }

        // Filter out generic strings
        String lower = clean.toLowerCase();
        if (lower.equals("google drive") || lower.equals("google drive - virus scan warning")
                || lower.contains("meet google drive") || lower.contains("access denied")
                || lower.contains("sign-in - google accounts")) {
            return null;
        }

        if (!clean.toLowerCase().endsWith(".pdf")) {
            clean = clean + ".pdf";
        }

        return clean;
    }

    /**
     * Helper to save a chosen cover image to app private storage.
     */
    public String saveCoverImageToInternalStorage(Uri uri) {
        if (uri == null) return null;
        try {
            File coversDir = new File(context.getFilesDir(), "covers");
            if (!coversDir.exists()) coversDir.mkdirs();
            File dest = new File(coversDir, "cover_" + System.currentTimeMillis() + ".jpg");

            InputStream in = context.getContentResolver().openInputStream(uri);
            if (in == null) return null;
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            in.close();

            if (bitmap != null) {
                FileOutputStream out = new FileOutputStream(dest);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out);
                out.flush();
                out.close();
                return dest.getAbsolutePath();
            }
        } catch (Exception ignored) {}
        return null;
    }

    public File getDownloadsDirectory() {
        File dir = new File(context.getFilesDir(), "downloaded_pdfs");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }
}
