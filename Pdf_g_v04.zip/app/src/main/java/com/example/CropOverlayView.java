package com.example;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.annotation.Nullable;

public class CropOverlayView extends View {

    private final RectF cropRect = new RectF();
    private final RectF imageBounds = new RectF();

    private final Paint scrimPaint = new Paint();
    private final Paint borderPaint = new Paint();
    private final Paint gridPaint = new Paint();
    private final Paint handlePaint = new Paint();
    private final Paint handleStrokePaint = new Paint();

    private static final int TOUCH_NONE = 0;
    private static final int TOUCH_MOVE = 1;
    private static final int TOUCH_TOP_LEFT = 2;
    private static final int TOUCH_TOP_RIGHT = 3;
    private static final int TOUCH_BOTTOM_LEFT = 4;
    private static final int TOUCH_BOTTOM_RIGHT = 5;
    private static final int TOUCH_EDGE_LEFT = 6;
    private static final int TOUCH_EDGE_TOP = 7;
    private static final int TOUCH_EDGE_RIGHT = 8;
    private static final int TOUCH_EDGE_BOTTOM = 9;

    private int currentTouchMode = TOUCH_NONE;
    private float lastTouchX;
    private float lastTouchY;
    private float touchTolerance;
    private float minCropSize;
    private boolean isInitialized = false;

    private int sourceBmpWidth = 0;
    private int sourceBmpHeight = 0;

    public interface OnCropChangedListener {
        void onCropRectChanged(RectF rect);
    }

    private OnCropChangedListener cropChangedListener;

    public CropOverlayView(Context context) {
        super(context);
        init();
    }

    public CropOverlayView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CropOverlayView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        float density = getResources().getDisplayMetrics().density;
        touchTolerance = 36 * density;
        minCropSize = 48 * density;

        // Scrim outside crop frame (semi-transparent dark)
        scrimPaint.setColor(Color.argb(175, 0, 0, 0));
        scrimPaint.setStyle(Paint.Style.FILL);

        // Crop rect border (bright cyan/blue or red)
        borderPaint.setColor(Color.rgb(33, 150, 243)); // Material Cyan/Blue
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(2.5f * density);
        borderPaint.setAntiAlias(true);

        // Rule of thirds grid
        gridPaint.setColor(Color.argb(120, 255, 255, 255));
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(1.0f * density);
        gridPaint.setAntiAlias(true);

        // Corner/Edge handles
        handlePaint.setColor(Color.WHITE);
        handlePaint.setStyle(Paint.Style.FILL);
        handlePaint.setAntiAlias(true);

        handleStrokePaint.setColor(Color.rgb(33, 150, 243));
        handleStrokePaint.setStyle(Paint.Style.STROKE);
        handleStrokePaint.setStrokeWidth(2.0f * density);
        handleStrokePaint.setAntiAlias(true);
    }

    public void setSourceImageDimensions(int width, int height) {
        this.sourceBmpWidth = width;
        this.sourceBmpHeight = height;
        this.isInitialized = false;
        updateImageBounds();
        invalidate();
    }

    public void resetToFullBounds() {
        if (!imageBounds.isEmpty()) {
            cropRect.set(imageBounds.left, imageBounds.top, imageBounds.right, imageBounds.bottom);
            isInitialized = true;
            if (cropChangedListener != null) {
                cropChangedListener.onCropRectChanged(cropRect);
            }
            invalidate();
        }
    }

    private void updateImageBounds() {
        int viewW = getWidth();
        int viewH = getHeight();
        if (viewW <= 0 || viewH <= 0) return;

        if (sourceBmpWidth > 0 && sourceBmpHeight > 0) {
            float scale = Math.min((float) viewW / sourceBmpWidth, (float) viewH / sourceBmpHeight);
            float displayedW = sourceBmpWidth * scale;
            float displayedH = sourceBmpHeight * scale;
            float offsetX = (viewW - displayedW) / 2.0f;
            float offsetY = (viewH - displayedH) / 2.0f;
            imageBounds.set(offsetX, offsetY, offsetX + displayedW, offsetY + displayedH);
        } else {
            imageBounds.set(0, 0, viewW, viewH);
        }

        // Initialize cropRect to 100% full image bounds by default
        if (!isInitialized || cropRect.isEmpty()) {
            cropRect.set(
                    imageBounds.left,
                    imageBounds.top,
                    imageBounds.right,
                    imageBounds.bottom
            );
            isInitialized = true;
            if (cropChangedListener != null) {
                cropChangedListener.onCropRectChanged(cropRect);
            }
        } else {
            // Keep cropRect within updated imageBounds
            clampCropRectToImageBounds();
        }
    }

    private void clampCropRectToImageBounds() {
        if (imageBounds.isEmpty()) return;
        if (cropRect.left < imageBounds.left) cropRect.left = imageBounds.left;
        if (cropRect.top < imageBounds.top) cropRect.top = imageBounds.top;
        if (cropRect.right > imageBounds.right) cropRect.right = imageBounds.right;
        if (cropRect.bottom > imageBounds.bottom) cropRect.bottom = imageBounds.bottom;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        updateImageBounds();
    }

    public void setOnCropChangedListener(OnCropChangedListener listener) {
        this.cropChangedListener = listener;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();

        // 1. Draw 4 scrim rectangles surrounding the crop box
        canvas.drawRect(0, 0, width, cropRect.top, scrimPaint); // top
        canvas.drawRect(0, cropRect.top, cropRect.left, cropRect.bottom, scrimPaint); // left
        canvas.drawRect(cropRect.right, cropRect.top, width, cropRect.bottom, scrimPaint); // right
        canvas.drawRect(0, cropRect.bottom, width, height, scrimPaint); // bottom

        // 2. Draw Rule of Thirds grid lines inside crop rect
        float thirdW = cropRect.width() / 3f;
        float thirdH = cropRect.height() / 3f;
        canvas.drawLine(cropRect.left + thirdW, cropRect.top, cropRect.left + thirdW, cropRect.bottom, gridPaint);
        canvas.drawLine(cropRect.left + 2 * thirdW, cropRect.top, cropRect.left + 2 * thirdW, cropRect.bottom, gridPaint);
        canvas.drawLine(cropRect.left, cropRect.top + thirdH, cropRect.right, cropRect.top + thirdH, gridPaint);
        canvas.drawLine(cropRect.left, cropRect.top + 2 * thirdH, cropRect.right, cropRect.top + 2 * thirdH, gridPaint);

        // 3. Draw crop border
        canvas.drawRect(cropRect, borderPaint);

        // 4. Draw corner drag handles
        float handleRadius = 10 * getResources().getDisplayMetrics().density;
        drawHandle(canvas, cropRect.left, cropRect.top, handleRadius);
        drawHandle(canvas, cropRect.right, cropRect.top, handleRadius);
        drawHandle(canvas, cropRect.left, cropRect.bottom, handleRadius);
        drawHandle(canvas, cropRect.right, cropRect.bottom, handleRadius);

        // Draw edge handles
        drawHandle(canvas, cropRect.centerX(), cropRect.top, handleRadius * 0.7f);
        drawHandle(canvas, cropRect.centerX(), cropRect.bottom, handleRadius * 0.7f);
        drawHandle(canvas, cropRect.left, cropRect.centerY(), handleRadius * 0.7f);
        drawHandle(canvas, cropRect.right, cropRect.centerY(), handleRadius * 0.7f);
    }

    private void drawHandle(Canvas canvas, float cx, float cy, float radius) {
        canvas.drawCircle(cx, cy, radius, handlePaint);
        canvas.drawCircle(cx, cy, radius, handleStrokePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                currentTouchMode = getTouchMode(x, y);
                lastTouchX = x;
                lastTouchY = y;
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = x - lastTouchX;
                float dy = y - lastTouchY;

                handleDrag(dx, dy);

                lastTouchX = x;
                lastTouchY = y;
                invalidate();
                if (cropChangedListener != null) {
                    cropChangedListener.onCropRectChanged(cropRect);
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                currentTouchMode = TOUCH_NONE;
                invalidate();
                return true;
        }

        return super.onTouchEvent(event);
    }

    private int getTouchMode(float x, float y) {
        if (distance(x, y, cropRect.left, cropRect.top) < touchTolerance) return TOUCH_TOP_LEFT;
        if (distance(x, y, cropRect.right, cropRect.top) < touchTolerance) return TOUCH_TOP_RIGHT;
        if (distance(x, y, cropRect.left, cropRect.bottom) < touchTolerance) return TOUCH_BOTTOM_LEFT;
        if (distance(x, y, cropRect.right, cropRect.bottom) < touchTolerance) return TOUCH_BOTTOM_RIGHT;

        if (Math.abs(x - cropRect.left) < touchTolerance && y >= cropRect.top && y <= cropRect.bottom) return TOUCH_EDGE_LEFT;
        if (Math.abs(x - cropRect.right) < touchTolerance && y >= cropRect.top && y <= cropRect.bottom) return TOUCH_EDGE_RIGHT;
        if (Math.abs(y - cropRect.top) < touchTolerance && x >= cropRect.left && x <= cropRect.right) return TOUCH_EDGE_TOP;
        if (Math.abs(y - cropRect.bottom) < touchTolerance && x >= cropRect.left && x <= cropRect.right) return TOUCH_EDGE_BOTTOM;

        if (cropRect.contains(x, y)) return TOUCH_MOVE;

        return TOUCH_NONE;
    }

    private void handleDrag(float dx, float dy) {
        float minX = imageBounds.isEmpty() ? 0 : imageBounds.left;
        float maxX = imageBounds.isEmpty() ? getWidth() : imageBounds.right;
        float minY = imageBounds.isEmpty() ? 0 : imageBounds.top;
        float maxY = imageBounds.isEmpty() ? getHeight() : imageBounds.bottom;

        switch (currentTouchMode) {
            case TOUCH_MOVE:
                if (cropRect.left + dx < minX) dx = minX - cropRect.left;
                if (cropRect.right + dx > maxX) dx = maxX - cropRect.right;
                if (cropRect.top + dy < minY) dy = minY - cropRect.top;
                if (cropRect.bottom + dy > maxY) dy = maxY - cropRect.bottom;
                cropRect.offset(dx, dy);
                break;

            case TOUCH_TOP_LEFT:
                cropRect.left = Math.max(minX, Math.min(cropRect.left + dx, cropRect.right - minCropSize));
                cropRect.top = Math.max(minY, Math.min(cropRect.top + dy, cropRect.bottom - minCropSize));
                break;

            case TOUCH_TOP_RIGHT:
                cropRect.right = Math.min(maxX, Math.max(cropRect.right + dx, cropRect.left + minCropSize));
                cropRect.top = Math.max(minY, Math.min(cropRect.top + dy, cropRect.bottom - minCropSize));
                break;

            case TOUCH_BOTTOM_LEFT:
                cropRect.left = Math.max(minX, Math.min(cropRect.left + dx, cropRect.right - minCropSize));
                cropRect.bottom = Math.min(maxY, Math.max(cropRect.bottom + dy, cropRect.top + minCropSize));
                break;

            case TOUCH_BOTTOM_RIGHT:
                cropRect.right = Math.min(maxX, Math.max(cropRect.right + dx, cropRect.left + minCropSize));
                cropRect.bottom = Math.min(maxY, Math.max(cropRect.bottom + dy, cropRect.top + minCropSize));
                break;

            case TOUCH_EDGE_LEFT:
                cropRect.left = Math.max(minX, Math.min(cropRect.left + dx, cropRect.right - minCropSize));
                break;

            case TOUCH_EDGE_TOP:
                cropRect.top = Math.max(minY, Math.min(cropRect.top + dy, cropRect.bottom - minCropSize));
                break;

            case TOUCH_EDGE_RIGHT:
                cropRect.right = Math.min(maxX, Math.max(cropRect.right + dx, cropRect.left + minCropSize));
                break;

            case TOUCH_EDGE_BOTTOM:
                cropRect.bottom = Math.min(maxY, Math.max(cropRect.bottom + dy, cropRect.top + minCropSize));
                break;
        }
    }

    private float distance(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2;
        float dy = y1 - y2;
        return (float) Math.hypot(dx, dy);
    }

    /**
     * Accurately converts crop overlay coordinates into source Bitmap coordinates,
     * taking into account uniform aspect-ratio scaling and fitCenter letterbox/pillarbox offsets.
     */
    public Rect calculateCropRect(int sourceWidth, int sourceHeight) {
        float viewWidth = getWidth();
        float viewHeight = getHeight();

        if (viewWidth <= 0 || viewHeight <= 0 || sourceWidth <= 0 || sourceHeight <= 0) {
            return new Rect(0, 0, Math.max(1, sourceWidth), Math.max(1, sourceHeight));
        }

        float scale = Math.min(viewWidth / (float) sourceWidth, viewHeight / (float) sourceHeight);
        float displayedWidth = sourceWidth * scale;
        float displayedHeight = sourceHeight * scale;
        float offsetX = (viewWidth - displayedWidth) / 2.0f;
        float offsetY = (viewHeight - displayedHeight) / 2.0f;

        // Clip cropRect strictly inside the displayed image region
        float validLeft = Math.max(cropRect.left, offsetX);
        float validTop = Math.max(cropRect.top, offsetY);
        float validRight = Math.min(cropRect.right, offsetX + displayedWidth);
        float validBottom = Math.min(cropRect.bottom, offsetY + displayedHeight);

        if (validRight <= validLeft || validBottom <= validTop) {
            return new Rect(0, 0, sourceWidth, sourceHeight);
        }

        int left = Math.max(0, Math.min(sourceWidth - 1, (int) Math.round((validLeft - offsetX) / scale)));
        int top = Math.max(0, Math.min(sourceHeight - 1, (int) Math.round((validTop - offsetY) / scale)));
        int right = Math.max(left + 1, Math.min(sourceWidth, (int) Math.round((validRight - offsetX) / scale)));
        int bottom = Math.max(top + 1, Math.min(sourceHeight, (int) Math.round((validBottom - offsetY) / scale)));

        return new Rect(left, top, right, bottom);
    }
}
