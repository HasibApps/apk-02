package com.example;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import java.io.File;

public class PdfDownloadService extends Service implements PdfDownloadHelper.DownloadStateListener {

    public static final String ACTION_START_DOWNLOAD = "com.example.ACTION_START_DOWNLOAD";
    public static final String ACTION_CANCEL_DOWNLOAD = "com.example.ACTION_CANCEL_DOWNLOAD";
    public static final String EXTRA_ITEM_ID = "extra_item_id";
    public static final String EXTRA_ITEM_TITLE = "extra_item_title";

    public static final String CHANNEL_ID = "pdf_download_channel";
    public static final int NOTIFICATION_ID = 3001;

    private NotificationManager notificationManager;
    private String currentTitle = "PDF Download";
    private String currentItemId = null;

    public static void startDownload(Context context, String itemId, String title) {
        Intent intent = new Intent(context, PdfDownloadService.class);
        intent.setAction(ACTION_START_DOWNLOAD);
        intent.putExtra(EXTRA_ITEM_ID, itemId);
        intent.putExtra(EXTRA_ITEM_TITLE, title);
        ContextCompat.startForegroundService(context, intent);
    }

    public static void cancelDownload(Context context, String itemId) {
        Intent intent = new Intent(context, PdfDownloadService.class);
        intent.setAction(ACTION_CANCEL_DOWNLOAD);
        intent.putExtra(EXTRA_ITEM_ID, itemId);
        context.startService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
        PdfDownloadHelper.getInstance(this).addStateListener(this);
    }

    @Override
    public void onDestroy() {
        PdfDownloadHelper.getInstance(this).removeStateListener(this);
        super.onDestroy();
    }

    @Override
    public void onDownloadProgress(String itemId, int percent, long downloadedBytes, long totalBytes) {
        if (currentItemId == null || currentItemId.equals(itemId)) {
            updateProgress(itemId, currentTitle, percent, downloadedBytes, totalBytes);
        }
    }

    @Override
    public void onDownloadSuccess(String itemId, File file) {
        notifyCompleted(currentTitle, file);
    }

    @Override
    public void onDownloadError(String itemId, String errorMessage) {
        checkIfAnyDownloadsActive();
    }

    @Override
    public void onDownloadPausedOrCancelled(String itemId, long downloadedBytes, long totalBytes) {
        checkIfAnyDownloadsActive();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "PDF Downloads",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Background PDF downloading and progress");
            channel.setSound(null, null);
            channel.enableVibration(false);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            String itemId = intent.getStringExtra(EXTRA_ITEM_ID);
            String title = intent.getStringExtra(EXTRA_ITEM_TITLE);

            if (ACTION_START_DOWNLOAD.equals(action)) {
                currentItemId = itemId;
                if (title != null && !title.isEmpty()) {
                    currentTitle = title;
                }
                startForegroundNotification("ডাউনলোড শুরু হচ্ছে...", 0, -1);
            } else if (ACTION_CANCEL_DOWNLOAD.equals(action)) {
                if (itemId != null) {
                    PdfDownloadHelper.getInstance(this).cancelDownload(itemId);
                }
                checkIfAnyDownloadsActive();
            }
        }
        return START_NOT_STICKY;
    }

    public void updateProgress(String itemId, String title, int percent, long downloadedBytes, long totalBytes) {
        if (title != null && !title.isEmpty()) {
            currentTitle = title;
        }
        currentItemId = itemId;

        String sizeText = PdfDownloadHelper.formatBanglaSize(downloadedBytes);
        String progressMsg;
        if (totalBytes > 0) {
            String totalSizeText = PdfDownloadHelper.formatBanglaSize(totalBytes);
            String percentText = PdfDownloadHelper.toBanglaDigits(String.valueOf(percent)) + "%";
            progressMsg = sizeText + " / " + totalSizeText + " (" + percentText + ")";
        } else {
            progressMsg = sizeText + " ডাউনলোড হচ্ছে...";
        }

        Notification notification = buildNotification(progressMsg, percent, totalBytes);
        if (notificationManager != null) {
            notificationManager.notify(NOTIFICATION_ID, notification);
        }
    }

    public void notifyCompleted(String title, File file) {
        Intent openIntent = new Intent(this, PdfViewerActivity.class);
        if (file != null) {
            openIntent.putExtra("pdf_path", file.getAbsolutePath());
            openIntent.setData(Uri.fromFile(file));
        }
        PendingIntent pi = PendingIntent.getActivity(this, 101, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_download)
                .setContentTitle(title != null ? title : "PDF Download")
                .setContentText("ডাউনলোড সম্পূর্ণ হয়েছে (ট্যাপ করে পড়ুন)")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setOngoing(false)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();

        if (notificationManager != null) {
            notificationManager.notify(NOTIFICATION_ID + 1, notification);
        }

        checkIfAnyDownloadsActive();
    }

    public void checkIfAnyDownloadsActive() {
        if (!PdfDownloadHelper.getInstance(this).hasActiveDownloads()) {
            stopForeground(true);
            stopSelf();
        }
    }

    private void startForegroundNotification(String contentText, int percent, long totalBytes) {
        Notification notification = buildNotification(contentText, percent, totalBytes);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildNotification(String contentText, int percent, long totalBytes) {
        Intent appIntent = new Intent(this, MainActivity.class);
        PendingIntent openAppPi = PendingIntent.getActivity(this, 100, appIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent cancelIntent = new Intent(this, PdfDownloadService.class);
        cancelIntent.setAction(ACTION_CANCEL_DOWNLOAD);
        if (currentItemId != null) {
            cancelIntent.putExtra(EXTRA_ITEM_ID, currentItemId);
        }
        PendingIntent cancelPi = PendingIntent.getService(this, 102, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_download)
                .setContentTitle(currentTitle)
                .setContentText(contentText)
                .setContentIntent(openAppPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .addAction(R.drawable.ic_close, "বাতিল করুন", cancelPi);

        if (totalBytes > 0 && percent >= 0) {
            builder.setProgress(100, percent, false);
        } else {
            builder.setProgress(100, 0, true);
        }

        return builder.build();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
