package com.example;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Settings & Permissions screen opened from the gear icon next to the Dark mode switch.
 * Every row shows the live status and jumps straight to the matching system settings page.
 */
public class PermissionsActivity extends AppCompatActivity {

    private static final int REQ_NOTIFICATIONS = 301;
    private static final int REQ_STORAGE = 302;

    private LinearLayout layoutRows;
    private View rowOverlay, rowAccessibility, rowNotifications, rowStorage, rowAppInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);

        // Dark screen: dark system bars with light icons
        getWindow().setStatusBarColor(Color.parseColor("#0B1020"));
        getWindow().setNavigationBarColor(Color.parseColor("#0B1020"));
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                .setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                .setAppearanceLightNavigationBars(false);

        View root = findViewById(R.id.permRoot);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        findViewById(R.id.btnPermBack).setOnClickListener(v -> finish());

        layoutRows = findViewById(R.id.layoutPermRows);
        LayoutInflater inflater = LayoutInflater.from(this);

        rowOverlay = inflater.inflate(R.layout.item_permission_row, layoutRows, false);
        rowAccessibility = inflater.inflate(R.layout.item_permission_row, layoutRows, false);
        rowNotifications = inflater.inflate(R.layout.item_permission_row, layoutRows, false);
        rowStorage = inflater.inflate(R.layout.item_permission_row, layoutRows, false);
        rowAppInfo = inflater.inflate(R.layout.item_permission_row, layoutRows, false);

        layoutRows.addView(rowOverlay);
        layoutRows.addView(rowAccessibility);
        layoutRows.addView(rowNotifications);
        layoutRows.addView(rowStorage);
        layoutRows.addView(rowAppInfo);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        // 1. Display over other apps
        bind(rowOverlay, "Display Over Other Apps",
                "ফ্লোটিং বাবল ও নেভিগেশন বার দেখানোর জন্য",
                isOverlayGranted(), "Active", "Enable",
                v -> openOverlaySettings());

        // 2. Accessibility service
        bind(rowAccessibility, "Accessibility Service",
                "Google Lens-এ অটো ক্লিক (Select text / Copy text) এর জন্য",
                isAccessibilityEnabled(), "Active", "Enable",
                v -> openAccessibilitySettings());

        // 3. Notifications
        bind(rowNotifications, "Notifications",
                "ব্যাকগ্রাউন্ড সার্ভিস ও ডাউনলোড নোটিফিকেশনের জন্য",
                isNotificationGranted(), "Active", "Enable",
                v -> requestNotifications());

        // 4. Storage / files
        boolean storageNeeded = Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2;
        bind(rowStorage, "Storage Access",
                storageNeeded ? "PDF ফাইল পড়ার জন্য" : "এই ভার্সনে আলাদা পারমিশন লাগে না",
                !storageNeeded || isStorageGranted(), "Active", "Enable",
                v -> requestStorage());

        // 5. All other app settings
        bind(rowAppInfo, "All App Permissions",
                "অ্যাপের সব পারমিশন ও সেটিংস একসাথে দেখুন",
                true, "Open", "Open",
                v -> openAppDetails());
        TextView status = rowAppInfo.findViewById(R.id.txtPermStatus);
        status.setText("App info");
        status.setTextColor(Color.parseColor("#94A3B8"));
        ((ImageView) rowAppInfo.findViewById(R.id.imgPermStatus)).setImageResource(R.drawable.ic_settings);
        ((ImageView) rowAppInfo.findViewById(R.id.imgPermStatus)).setColorFilter(Color.parseColor("#94A3B8"));
    }

    private void bind(View row, String title, String desc, boolean granted,
                      String activeLabel, String enableLabel, View.OnClickListener onClick) {
        ((TextView) row.findViewById(R.id.txtPermTitle)).setText(title);
        ((TextView) row.findViewById(R.id.txtPermDesc)).setText(desc);

        ImageView icon = row.findViewById(R.id.imgPermStatus);
        icon.clearColorFilter();
        icon.setImageResource(granted ? R.drawable.ic_perm_ok : R.drawable.ic_perm_off);

        TextView status = row.findViewById(R.id.txtPermStatus);
        status.setText(granted ? "Active" : "Not granted");
        status.setTextColor(Color.parseColor(granted ? "#10B981" : "#F59E0B"));

        TextView btn = row.findViewById(R.id.btnPermAction);
        btn.setText(granted ? activeLabel : enableLabel);
        btn.setBackgroundResource(granted ? R.drawable.bg_perm_btn_active : R.drawable.bg_perm_btn_enable);
        btn.setTextColor(Color.parseColor(granted ? "#9CA3AF" : "#FFFFFF"));
        btn.setOnClickListener(onClick);
        // The whole row is clickable too
        row.setOnClickListener(onClick);
    }

    // ---------------- status checks ----------------

    private boolean isOverlayGranted() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private boolean isAccessibilityEnabled() {
        try {
            int enabled = Settings.Secure.getInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (enabled != 1) return false;
            String list = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(list)) return false;
            ComponentName cn = new ComponentName(this, LensAccessibilityService.class);
            String full = cn.flattenToString();
            String shortName = cn.flattenToShortString();
            TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
            splitter.setString(list);
            while (splitter.hasNext()) {
                String s = splitter.next();
                if (s.equalsIgnoreCase(full) || s.equalsIgnoreCase(shortName)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean isNotificationGranted() {
        if (Build.VERSION.SDK_INT >= 33) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled();
    }

    private boolean isStorageGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    // ---------------- actions ----------------

    private void openOverlaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            openAppDetails();
        }
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            Toast.makeText(this, "ইনস্টলড সার্ভিস থেকে \"PDF Gallery – Lens Auto Copy\" চালু করুন", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            openAppDetails();
        }
    }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !isNotificationGranted()
                && (!askedNotifOnce() || ActivityCompat.shouldShowRequestPermissionRationale(
                        this, Manifest.permission.POST_NOTIFICATIONS))) {
            markAskedNotif();
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        openNotificationSettings();
    }

    private boolean askedNotifOnce() {
        return getSharedPreferences("perm_prefs", MODE_PRIVATE).getBoolean("asked_notif", false);
    }

    private void markAskedNotif() {
        getSharedPreferences("perm_prefs", MODE_PRIVATE).edit().putBoolean("asked_notif", true).apply();
    }

    private void openNotificationSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        } catch (Exception e) {
            openAppDetails();
        }
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.S_V2 || isStorageGranted()) {
            openAppDetails();
            return;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                || !getSharedPreferences("perm_prefs", MODE_PRIVATE).getBoolean("asked_storage", false)) {
            getSharedPreferences("perm_prefs", MODE_PRIVATE).edit().putBoolean("asked_storage", true).apply();
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
        } else {
            openAppDetails();
        }
    }

    private void openAppDetails() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            Toast.makeText(this, "সেটিংস খোলা যায়নি", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
    }
}
