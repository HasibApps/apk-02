# Lens Page: Note / Copy / Auto Agent

- Note icon  -> opens the Unlimited Note editor (LensNoteActivity).
- Copy icon  -> on the REAL Google Lens screen: taps "Select text" -> "Copy text" (LensAccessibilityService),
                reads the clipboard (ClipboardGrabActivity), appends to the Unlimited Note, opens the note.
                No own OCR any more.
- Agent icon -> same Lens select+copy for every page -> append -> load next page in Lens, until the last page.

One-time setup: Settings > Accessibility > "PDF Gallery – Lens Auto Copy" > ON.
(Android 13+ sideloaded APK: App info > ⋮ > "Allow restricted settings" first.)

If your Lens uses other button labels, edit SELECT_TEXT_LABELS / COPY_TEXT_LABELS in LensAccessibilityService.java.
PageOcr.java is no longer used and can be deleted.

## Speed (Agent)
- Next page image is rendered in parallel while Lens copies the current page; JPEG instead of PNG.
- Lens select/copy polling every ~70 ms, "Select text" retried every 1 s, single tree walk.
- Clipboard read directly from the accessibility service (falls back to the invisible activity).
- No synchronous disk commits of the big notes file per page.
